﻿Partial Class _SolicitudesTramitePersonal
    Inherits System.Web.UI.Page
    Dim ctf As Integer
    Dim mes As Integer
    Dim anio, estado, prioridad, tip_sol As String
    Dim respuesta As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Session("id_per") Is Nothing) Then

            Response.Redirect("http://intranet.usat.edu.pe/campusvirtual/sinacceso.html")

        End If

        Session("codigo_ctf") = Request.QueryString("ctf")

        If Not IsPostBack Then

            If Request.QueryString("anio") <> "" Then
                Me.ddlAño.SelectedValue = Request.QueryString("anio")
            End If
            If Request.QueryString("mes") <> "" Then
                Me.ddlMes.SelectedValue = Request.QueryString("mes")
            End If
            If Request.QueryString("estado") <> "" Then
                Me.ddlEstado.SelectedValue = Request.QueryString("estado")
            End If
            If Request.QueryString("prioridad") <> "" Then
                Me.ddlPrioridad.SelectedValue = Request.QueryString("prioridad")
            End If
            If Request.QueryString("tip_sol") <> "" Then
                Me.ddlTipoSolicitud.SelectedValue = Request.QueryString("tip_sol")
            End If

            If Request.QueryString("respuesta") <> "" Then
                respuesta = Request.QueryString("respuesta")
            End If

            If CInt(Session("codigo_ctf")) = 195 Then 'TipoFuncion: CONTROL LICENCIAS Y PERMISOS
                Me.lblTipo_Solic.Text = "Licencias y Permisos por Horas"
                Me.lblTipo_Solic1.Text = "Licencias y Permisos por Horas"
            ElseIf CInt(Session("codigo_ctf")) = 197 Then
                Me.lblTipo_Solic.Text = "Permisos por Horas"
                Me.lblTipo_Solic1.Text = "Permisos por Horas"
                Me.ddlTipoSolicitud.Visible = False
            ElseIf CInt(Session("codigo_ctf")) = 137 Then
                Me.lblTipo_Solic.Text = "Vacaciones"
                Me.lblTipo_Solic1.Text = "Vacaciones"
                Me.ddlTipoSolicitud.Visible = False
            End If

            Me.divConfirmaRechazar.Visible = False
            Me.divConfirmaCancelar.Visible = False

            lblMensaje.Visible = False 'Se añadió

            ConsultarListaSolicitudesPersonal()

            valida_respuesta()
            'Me.btnCancelar.Visible = False
            valida_estado()

        End If

    End Sub

    Private Sub valida_respuesta()

        If respuesta = "A" Then
            Me.lblMensaje0.Text = "** AVISO :  La Solicitud se ha aprobado y se ha creado el registro de permiso correctamente"""
        ElseIf respuesta = "R" Then
            Me.lblMensaje0.Text = "** AVISO :  La Solicitud se ha Rechazado correctamente"
        ElseIf respuesta = "C" Then
            Me.lblMensaje0.Text = "** NOTA : Operación Cancelada"
        End If

    End Sub

    Private Sub valida_estado()

        If Me.ddlEstado.SelectedValue = "AP" Then
            Me.btnAprobar.Enabled = False
            Me.btnRechazar.Enabled = False
            Me.btnCancelar.Visible = True
        ElseIf Me.ddlEstado.SelectedValue = "AD" Then 'Pendientes
            Me.btnAprobar.Enabled = True
            Me.btnRechazar.Enabled = True
            Me.btnCancelar.Visible = False
        ElseIf Me.ddlEstado.SelectedValue = "RE" Then
            Me.btnAprobar.Enabled = False
            Me.btnRechazar.Enabled = False
            Me.btnCancelar.Visible = False
        ElseIf Me.ddlEstado.SelectedValue = "TO" Then
            Me.btnAprobar.Enabled = True
            Me.btnRechazar.Enabled = True
            Me.btnCancelar.Visible = True
        End If

    End Sub

    Public Sub ConsultarListaSolicitudesPersonal()

        Me.gvCarga.DataSource = Nothing
        Me.gvCarga.DataBind()
        'Me.celdaGrid.Visible = True
        'Me.celdaGrid.InnerHtml = ""

        registrar_filtros()

        '  = Request.QueryString("ctf")
        ctf = Session("codigo_ctf")

        Try
            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos

            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()

            dt = obj.TraerDataTable("ListaSolicitudTramitePersonal", anio, mes, ctf, estado, prioridad, tip_sol)

            If dt.Rows.Count > 0 Then
                Me.gvCarga.DataSource = dt
                Me.gvCarga.DataBind()
            Else
                Me.gvCarga.DataSource = Nothing
                Me.gvCarga.DataBind()
                'Me.celdaGrid.Visible = True
                'Me.celdaGrid.InnerHtml = "** AVISO :  No Existen Solicitudes con los parámetros seleccionados"
                Me.lblMensaje.Text = "** AVISO :  No Existen Solicitudes con los Parámetros seleccionados"

                Me.btnAprobar.Enabled = False 'Se añadió
                Me.btnRechazar.Enabled = False 'Se añadió
                Me.btnCancelar.Enabled = False 'Se añadió

            End If

            obj.CerrarConexion()

            'Me.gvCarga.DataSource = Nothing
            'Me.gvCarga.DataBind()
            'Me.celdaGrid.Visible = True

        Catch ex As Exception
            Me.lblMensaje.Text = ex.Message & " - " & ex.StackTrace '"Error al consultar.."
        End Try

    End Sub

    Private Sub registrar_filtros()

        anio = Me.ddlAño.SelectedValue
        mes = Me.ddlMes.SelectedValue
        estado = Me.ddlEstado.SelectedValue
        prioridad = Me.ddlPrioridad.SelectedValue
        tip_sol = Me.ddlTipoSolicitud.SelectedValue 'L o P

    End Sub

    Protected Sub cboAño_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlAño.SelectedIndexChanged
        ConsultarListaSolicitudesPersonal()
        Me.lblMensaje0.Text = ""
    End Sub

    Protected Sub cboMes_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMes.SelectedIndexChanged
        ConsultarListaSolicitudesPersonal()
        Me.lblMensaje0.Text = ""
    End Sub

    Protected Sub cboEstado_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlEstado.SelectedIndexChanged

        ConsultarListaSolicitudesPersonal()
        Me.lblMensaje0.Text = ""

        valida_estado()

    End Sub

    Protected Sub cboPrioridad_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlPrioridad.SelectedIndexChanged
        ConsultarListaSolicitudesPersonal()
        Me.lblMensaje0.Text = ""
    End Sub

    Protected Sub cboTipoSolicitud_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlTipoSolicitud.SelectedIndexChanged
        ConsultarListaSolicitudesPersonal()
        Me.lblMensaje0.Text = ""
    End Sub

    Protected Sub gvCarga_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvCarga.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim fila As Data.DataRowView
            fila = e.Row.DataItem

            'Dim chk As CheckBox = CType(e.Row.FindControl("CheckBox1"), CheckBox)
            'chk.Visible = False
            'e.Row.Cells(1).Text = e.Row.RowIndex + 1

            Dim cod, codi As Integer
            cod = fila.Row("codigo_ST")
            codi = fila.Row("codigo_EST")

            'e.Row.Attributes.Add("OnMouseOver", "Resaltar(1,this,'S')")
            'e.Row.Attributes.Add("OnMouseOut", "Resaltar(0,this,'S')")
            CType(e.Row.FindControl("CheckBox1"), CheckBox).Attributes.Add("OnClick", "PintarFilaMarcada(this.parentNode.parentNode,this.checked)")

            If e.Row.Cells(4).Text = "Urgente" Then
                e.Row.Cells(4).Font.Bold = False
                e.Row.Cells(4).ForeColor = System.Drawing.Color.Blue
                'e.Row.Cells(4).Attributes.Add("HyperLink", "../SolicitudTramite.aspx")
            End If

            e.Row.Cells(14).ForeColor = IIf(fila.Row("Estado") = "Pendiente", Drawing.Color.Red, Drawing.Color.Blue)
            e.Row.Cells(14).Font.Underline = IIf(fila.Row("Estado") <> "Pendiente", True, False)
            Dim pagina As String = "<a href='AprobacionSolicitudTramitePersonal.aspx?cod=" & cod & "&codi=" & codi & "&anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&prioridad=" & prioridad & "&tip_sol=" & tip_sol & "'>" & e.Row.Cells(14).Text & "</a>"
            'e.Row.Cells(11).Text = IIf(fila.Row("Estado") <> "Generado", "<a href='SolicitudTramite.aspx?cod=" + cod + "'>" + e.Row.Cells(11).Text + "</a>", e.Row.Cells(11).Text)
            e.Row.Cells(14).Text = IIf(fila.Row("Estado") <> "Pendiente", pagina, e.Row.Cells(14).Text)

            If fila.Row("Estado") <> "Pendiente" And fila.Row("Estado") <> "Aprobado Personal" Then
                e.Row.Cells(0).Text = ""
            End If

        End If

    End Sub

    Protected Sub btnAprobar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAprobar.Click

        Dim vMensaje As String

        Dim Fila As GridViewRow

        Try
            Dim x As Integer
            x = 0
            For i As Integer = 0 To Me.gvCarga.Rows.Count - 1
                Fila = Me.gvCarga.Rows(i)
                If Fila.RowType = DataControlRowType.DataRow Then
                    If CType(Fila.FindControl("CheckBox1"), CheckBox).Checked = True Then

                        If gvCarga.DataKeys.Item(Fila.RowIndex).Values("Estado") = "Pendiente" Then
                            'parteAprobar()
                            ctf = Session("codigo_ctf") 'ctf 

                            Dim cod, codi As Integer
                            cod = gvCarga.DataKeys.Item(Fila.RowIndex).Values("codigo_ST")
                            codi = gvCarga.DataKeys.Item(Fila.RowIndex).Values("codigo_EST")

                            registrar_filtros()

                            Response.Redirect("AprobacionSolicitudTramitePersonal.aspx?cod=" & cod & "&codi=" & codi & "&anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&prioridad=" & prioridad & "&tip_sol=" & tip_sol)

                        Else
                            Me.lblMensaje0.Text = "** NOTA :  La Solicitud de Trámite ya se ha Evaluado"
                            ConsultarListaSolicitudesPersonal()
                            Exit Sub

                        End If
                    Else
                        x = x + 1
                    End If
                End If
            Next
            If x = Me.gvCarga.Rows.Count Then
                vMensaje = "*Aviso : Debe seleccionar un registro de la lista"
                Dim myscript As String = "alert('" & vMensaje & "')"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                Exit Sub
                ConsultarListaSolicitudesPersonal()
            End If

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

    End Sub

    Private Sub parteAprobar()

        ctf = Session("codigo_ctf") 'ctf 

        Dim Fila As GridViewRow
        Try
            Dim x As Integer
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            x = 0
            For i As Integer = 0 To Me.gvCarga.Rows.Count - 1
                Fila = Me.gvCarga.Rows(i)
                If Fila.RowType = DataControlRowType.DataRow Then
                    If CType(Fila.FindControl("CheckBox1"), CheckBox).Checked = True Then
                        Dim cod, codi As Integer
                        cod = gvCarga.DataKeys.Item(Fila.RowIndex).Values("codigo_ST")
                        codi = gvCarga.DataKeys.Item(Fila.RowIndex).Values("codigo_EST")

                        registrar_filtros()

                        If gvCarga.DataKeys.Item(Fila.RowIndex).Values("Estado") = "Pendiente" Then 'Lo pendiente es lo Enviado por Director                        
                            Response.Redirect("AprobacionSolicitudTramitePersonal.aspx?cod=" & cod & "&codi=" & codi & "&anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&prioridad=" & prioridad)
                        Else
                            Me.lblMensaje0.Text = "** NOTA :  La Solicitud de Trámite ya se ha Evaluado"
                            ConsultarListaSolicitudesPersonal()
                            Exit Sub
                        End If
                    Else
                        x = x + 1
                    End If
                End If
            Next

            If x = Me.gvCarga.Rows.Count Then
                Me.lblMensaje0.Text = "** NOTA : Debe Seleccionar un registro de la lista"
            End If
            obj.CerrarConexion()

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

        ConsultarListaSolicitudesPersonal()

    End Sub

    Protected Sub btnRechazar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRechazar.Click

        Dim vMensaje As String

        Dim Fila As GridViewRow

        Try
            Dim x As Integer
            x = 0
            For i As Integer = 0 To Me.gvCarga.Rows.Count - 1
                Fila = Me.gvCarga.Rows(i)
                If Fila.RowType = DataControlRowType.DataRow Then
                    If CType(Fila.FindControl("CheckBox1"), CheckBox).Checked = True Then

                        If gvCarga.DataKeys.Item(Fila.RowIndex).Values("Estado") = "Pendiente" Then
                            Me.divListado.Visible = False
                            Me.divConfirmaRechazar.Visible = True
                        Else
                            Me.lblMensaje0.Text = "** NOTA : No puede Rechazar, La Solicitud ya se ha Evaluado. Si desea Eliminarla puede cancelarla con el botón: 'Cancelar Solicitud'"
                            ConsultarListaSolicitudesPersonal()
                            Exit Sub
                        End If
                    Else
                        x = x + 1
                    End If
                End If
            Next
            If x = Me.gvCarga.Rows.Count Then
                vMensaje = "*Aviso : Debe seleccionar un registro de la lista"
                Dim myscript As String = "alert('" & vMensaje & "')"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                Exit Sub
                ConsultarListaSolicitudesPersonal()
            End If

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

    End Sub

    Private Sub parteRechazar()

        Dim Fila As GridViewRow
        Try
            Dim x As Integer
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            x = 0
            For i As Integer = 0 To Me.gvCarga.Rows.Count - 1
                Fila = Me.gvCarga.Rows(i)
                If Fila.RowType = DataControlRowType.DataRow Then
                    If CType(Fila.FindControl("CheckBox1"), CheckBox).Checked = True Then
                        obj.Ejecutar("RechazaSolicitudTramite", gvCarga.DataKeys.Item(Fila.RowIndex).Values("codigo_ST"), gvCarga.DataKeys.Item(Fila.RowIndex).Values("codigo_EST"), CInt(Session("id_per")), "")
                        Me.lblMensaje0.Text = "** AVISO :  La Solicitud se ha Rechazado correctamente"
                    Else
                        x = x + 1
                    End If
                End If
            Next
            If x = Me.gvCarga.Rows.Count Then
                Me.lblMensaje0.Text = "** NOTA : Debe seleccionar un registro de la lista"
            End If
            obj.CerrarConexion()

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

        ConsultarListaSolicitudesPersonal()

    End Sub

    Protected Sub btnConfirmaRechazarSI_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmaRechazarSI.Click
        Me.divListado.Visible = True
        Me.divConfirmaRechazar.Visible = False
        parteRechazar()
    End Sub

    Protected Sub btnConfirmaRechazarNO_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmaRechazarNO.Click
        Me.divListado.Visible = True
        Me.divConfirmaRechazar.Visible = False
        ConsultarListaSolicitudesPersonal()
        respuesta = "C"
        valida_respuesta()
    End Sub

    Protected Sub btnCancelar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelar.Click

        Dim vMensaje As String

        Dim Fila As GridViewRow

        Try
            Dim x As Integer
            x = 0
            For i As Integer = 0 To Me.gvCarga.Rows.Count - 1
                Fila = Me.gvCarga.Rows(i)
                If Fila.RowType = DataControlRowType.DataRow Then
                    If CType(Fila.FindControl("CheckBox1"), CheckBox).Checked = True Then

                        If gvCarga.DataKeys.Item(Fila.RowIndex).Values("Estado") = "Aprobado Personal" Then
                            Me.divListado.Visible = False
                            Me.divConfirmaCancelar.Visible = True
                        Else
                            Me.lblMensaje0.Text = "** NOTA : No puede Cancelar la Solicitud porque No ha sido Aprobada"
                            ConsultarListaSolicitudesPersonal()
                            Exit Sub
                        End If
                    Else
                        x = x + 1
                    End If
                End If
            Next
            If x = Me.gvCarga.Rows.Count Then
                vMensaje = "*Aviso : Debe seleccionar un registro de la lista"
                Dim myscript As String = "alert('" & vMensaje & "')"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                Exit Sub
                ConsultarListaSolicitudesPersonal()
            End If

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

    End Sub

    Private Sub parteCancelar()

        Dim Fila As GridViewRow
        Try
            Dim x As Integer
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            x = 0
            For i As Integer = 0 To Me.gvCarga.Rows.Count - 1
                Fila = Me.gvCarga.Rows(i)
                If Fila.RowType = DataControlRowType.DataRow Then
                    If CType(Fila.FindControl("CheckBox1"), CheckBox).Checked = True Then
                        obj.Ejecutar("CancelaSolicitudTramite", gvCarga.DataKeys.Item(Fila.RowIndex).Values("codigo_ST"))
                        Me.lblMensaje0.Text = "** AVISO :  La Solicitud se ha CANCELADO y se ha Eliminado el registro del Permiso correspondiente"
                    Else
                        x = x + 1
                    End If
                End If
            Next
            If x = Me.gvCarga.Rows.Count Then
                Me.lblMensaje0.Text = "** NOTA : Debe seleccionar un registro de la lista"
            End If
            obj.CerrarConexion()

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

        ConsultarListaSolicitudesPersonal()

    End Sub

    Protected Sub btnConfirmaCancelarSI_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmaCancelarSI.Click
        Me.divListado.Visible = True
        Me.divConfirmaCancelar.Visible = False
        parteCancelar()
    End Sub

    Protected Sub btnConfirmaCancelarNO_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmaCancelarNO.Click
        Me.divListado.Visible = True
        Me.divConfirmaCancelar.Visible = False
        ConsultarListaSolicitudesPersonal()
        respuesta = "C"
        valida_respuesta()
    End Sub
End Class
