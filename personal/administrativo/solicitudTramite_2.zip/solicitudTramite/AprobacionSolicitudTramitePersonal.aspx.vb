﻿Partial Class _AprobacionSolicitudTramitePersonal
    Inherits System.Web.UI.Page
    Dim cod_ST As Integer
    Dim mes, categ_permiso, ctf As Integer
    Dim anio, estado, prioridad, tip_sol As String
    Dim respuesta As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Session("id_per") Is Nothing) Then

            Response.Redirect("http://intranet.usat.edu.pe/campusvirtual/sinacceso.html")

        End If

        If Not IsPostBack Then
            'Response.Write(Request.QueryString("id")
            Me.hdid.Value = CInt(Session("id_per")) 'Por sesión
            Me.hdctf.Value = CInt(Session("codigo_ctf"))

            cod_ST = Request.QueryString("cod")
            Me.lblcod_EST.Text = Request.QueryString("codi")

            registrar_filtros()

            Me.divConfirmaAprobar.Visible = False
            Me.divConfirmaRechazar.Visible = False

            carga_horas()

            Me.txtDesde.Text = DateTime.Now.ToString("dd/MM/yyyy")
            Me.txtHasta.Text = DateTime.Now.ToString("dd/MM/yyyy")

            Me.txtDesde.Text = DateSerial(Now.Date.Year, Now.Month, 1)
            Me.txtHasta.Text = DateSerial(Year(Now.Date), Month(Now.Date) + 1, 0)

            If tip_sol = "L" Then
                Me.lblTipo_Solic.Text = "Licencia "
                Me.lblTipo_Solic1.text = "Licencia "
            ElseIf tip_sol = "P" Then
                Me.lblTipo_Solic.Text = "Permiso por Horas "
                Me.lblTipo_Solic1.text = "Permiso por Horas "
            End If

            calcula_dias()

            ConsultarTipoSolicitud()

            ConsultarSolicitudTramite()

            ConsultarAdjuntos()

        End If

    End Sub

    Public Sub ConsultarSolicitudTramite()

        Try

            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos

            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            dt = obj.TraerDataTable("ConsultaSolicitudTramitePersonal", cod_ST)
            obj.CerrarConexion()

            Me.lblNumero_Tramite.Text = dt.Rows(0).Item("codigo_ST")
            Me.lblNumero_Tramite1.Text = dt.Rows(0).Item("codigo_ST")
            Me.lblEstado.Text = dt.Rows(0).Item("Estado")
            Me.lblcodigo_Per.Text = dt.Rows(0).Item("codigo_Per")

            If dt.Rows(0).Item("Estado") <> "Aprobado Director" Then
                desactiva_controles()
            End If

            Me.ddlTipoSolicitud.SelectedValue = dt.Rows(0).Item("codigo_TST")
            If Me.ddlTipoSolicitud.SelectedValue < 3 Then 'Licencias
                categ_permiso = 2 'Licencias S/G y C/G
            ElseIf Me.ddlTipoSolicitud.SelectedValue = 4 Then 'Permiso
                categ_permiso = 1 'Permisos
            End If
            ConsultarTipoPermiso()

            If dt.Rows(0).Item("Estado") = "Aprobado Director" Then
                Me.txtFechaEstado.Text = FormatDateTime(dt.Rows(0).Item("Fecha_Respuesta"), DateFormat.GeneralDate)
                Me.nombre_titulo.Text = "Evaluación de la"
                valida_Goce()
            ElseIf dt.Rows(0).Item("Estado") = "Aprobado Personal" Then 'Para Aprobados
                Me.txtFechaEstado.Text = FormatDateTime(dt.Rows(0).Item("Fecha_Evaluacion"), DateFormat.GeneralDate)
                Me.nombre_titulo.Text = "Vista de la"
                Me.ddlTipoPermiso.SelectedValue = dt.Rows(0).Item("codigo_Tpp")
                Me.chkConGoce.Checked = dt.Rows(0).Item("conGoce_EST")
                If Me.chkConGoce.Checked = True Then
                    Me.chkConGoce.Text = "Sí"
                Else
                    Me.chkConGoce.Text = "No"
                End If
            Else  'Rechazados
                Me.txtFechaEstado.Text = FormatDateTime(dt.Rows(0).Item("Fecha_Evaluacion"), DateFormat.GeneralDate)
                Me.nombre_titulo.Text = "Vista de la"
            End If

            If dt.Rows(0).Item("Prioridad") = "Urgente" Then
                Me.lblprioridad.ForeColor = Drawing.Color.OrangeRed
                Me.lblprioridad.Text = "Urgente"
            Else
                Me.lblprioridad.Text = "Normal"
            End If

            Me.lblColaborador.Text = dt.Rows(0).Item("Colaborador")
            Me.txtMotivo.Text = dt.Rows(0).Item("motivo")
            If dt.Rows(0).Item("Estado") = "Aprobado Director" Then
                Me.txtObservacionPer.Text = dt.Rows(0).Item("motivo")
            Else
                Me.txtObservacionPer.Text = dt.Rows(0).Item("Observacion_Per")
            End If

            Me.txtDesde.Text = FormatDateTime(dt.Rows(0).Item("fechahoraInicio_ST"), DateFormat.ShortDate)
            Me.txtHasta.Text = FormatDateTime(dt.Rows(0).Item("fechahoraFin_ST"), DateFormat.ShortDate)

            calcula_dias()

            If Me.ddlTipoSolicitud.SelectedValue = 4 Then 'Si Permiso toma las horas guardadas por Vigilancia
                'Me.ddlHoraInicio.Text = CDate(dt.Rows(0).Item("fechahoraIniAutorizada_ST")).ToString("MM\/dd\/yyyy")
                'Me.ddlHoraFin.Text = CDate(dt.Rows(0).Item("fechahoraFinAutorizada_ST")).ToString("HH:mm")

                '--Horas Solicitadas
                Me.ddlHoraInicioSol.Text = FormatDateTime(dt.Rows(0).Item("fechahoraInicio_ST"), DateFormat.ShortTime)
                Me.ddlHoraFinSol.Text = FormatDateTime(dt.Rows(0).Item("fechahoraFin_ST"), DateFormat.ShortTime)

                '--Horas Reales usadas y grabadas desde Vigilancia
                If dt.Rows(0).Item("fechahoraIniAutorizada_ST") <> "" Then                
                    Me.ddlHoraInicio.Visible = False
                    Me.txtHInicio.Text = FormatDateTime(dt.Rows(0).Item("fechahoraIniAutorizada_ST"), DateFormat.ShortTime)
                    Me.txtHInicio.Enabled = False
                Else
                    Me.ddlHoraInicio.Visible = True
                    Me.ddlHoraInicio.ForeColor = Drawing.Color.DarkRed
                    Me.txtHInicio.Visible = False
                End If

                If dt.Rows(0).Item("fechahoraFinAutorizada_ST") <> "" Then
                    'ddlHoraFin.Text = FormatDateTime(dt.Rows(0).Item("fechahoraFinAutorizada_ST"), DateFormat.ShortTime) 'Extrae solo la Hora
                    Me.ddlHoraFin.Visible = False
                    Me.txtHFin.Text = FormatDateTime(dt.Rows(0).Item("fechahoraFinAutorizada_ST"), DateFormat.ShortTime)
                    Me.txtHFin.Enabled = False
                Else
                    Me.ddlHoraFin.Visible = True
                    Me.ddlHoraFin.ForeColor = Drawing.Color.DarkRed
                    Me.txtHFin.Visible = False
                End If

                If (Me.txtHInicio.Visible = True And Me.txtHFin.Visible = True) Or (Me.ddlHoraInicio.ForeColor <> Drawing.Color.DarkRed And Me.ddlHoraFin.ForeColor <> Drawing.Color.DarkRed) Then
                    calcula_horas()
                End If

            End If

            valida_TipoSolicitud()

            Me.txtObservacion.Text = dt.Rows(0).Item("Observacion")

        Catch ex As Exception
            'Me.lblMensaje.Text = "Error al cargar la Solicitud de Trámite"
        End Try

    End Sub

    Public Sub ConsultarTipoSolicitud()
        Try
            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()

            dt = obj.TraerDataTable("ListaTipoSolicitudTramite", "")
            obj.CerrarConexion()

            Me.ddlTipoSolicitud.DataTextField = "nombre_TST"
            Me.ddlTipoSolicitud.DataValueField = "codigo_TST"
            Me.ddlTipoSolicitud.DataSource = dt
            Me.ddlTipoSolicitud.DataBind()

            'valida_TipoSolicitud()

        Catch ex As Exception
            'Me.lblMensaje.Text = "Error al cargar los Tipos de Solicitud Trámite"
        End Try
    End Sub

    Public Sub valida_TipoSolicitud()

        If Me.ddlTipoSolicitud.SelectedValue = 4 Then 'Permisos
            Me.lblHoraFin.Visible = True
            Me.lblHoraInicio.Visible = True
            Me.lblHoras.Visible = True
            'Me.ddlHoraInicio.Visible = True
            'Me.ddlHoraFin.Visible = True
            Me.lblTotalHoras.Visible = True
            Me.lblHoraInicioSol.Visible = True
            Me.lblHoraFinSol.Visible = True
            Me.ddlHoraInicioSol.Visible = True
            Me.ddlHoraFinSol.Visible = True
            Me.lblNumDias.Visible = False
            Me.lblNum_dias.Text = "0"
            Me.lblNum_dias.Visible = False

        Else
            Me.lblTotalHoras.Visible = False
            Me.lblHoraInicio.Visible = False
            Me.lblHoraFin.Visible = False
            Me.lblHoras.Visible = False
            Me.ddlHoraInicio.Visible = False
            Me.ddlHoraFin.Visible = False
            Me.lblHoraInicioSol.Visible = False
            Me.lblHoraFinSol.Visible = False
            Me.ddlHoraInicioSol.Visible = False
            Me.ddlHoraFinSol.Visible = False

            Me.lblNumDias.Visible = True
            Me.lblNum_dias.Visible = True

            Me.txtHInicio.Visible = False
            Me.txtHFin.Visible = False
        End If

    End Sub

    Public Sub ConsultarAdjuntos()
        Me.gvCarga.DataSource = Nothing
        Me.gvCarga.DataBind()
        Me.celdaGrid.Visible = True
        Me.celdaGrid.InnerHtml = ""

        Try
            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos

            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            dt = obj.TraerDataTable("ConsultaAdjuntoTramite", cod_ST)

            If dt.Rows.Count > 0 Then
                Me.gvCarga.DataSource = dt
                Me.gvCarga.DataBind()

            Else
                Me.gvCarga.DataSource = Nothing
                Me.gvCarga.DataBind()
                Me.celdaGrid.Visible = True
                Me.celdaGrid.InnerHtml = "Aviso: No existen Archivos Adjuntos relacionados"

                Me.lblAdjuntos.Visible = False 'Se añadió

            End If
            obj.CerrarConexion()
        Catch ex As Exception
            Me.lblMensaje0.Text = ex.Message & " - " & ex.StackTrace '"Error al consultar.."
        End Try
    End Sub

    Private Sub valida_Goce()

        If Me.ddlTipoSolicitud.SelectedValue = 2 Or Me.ddlTipoSolicitud.SelectedValue = 3 Then
            Me.chkConGoce.Checked = True 'Licencia C/Goce o Vacaciones
            Me.lblConGoce.text = "Sí"
            Me.chkConGoce.Enabled = False
        ElseIf Me.ddlTipoSolicitud.SelectedValue = 1 Then
            Me.chkConGoce.Checked = False  'Licencia S/Goce 
            Me.lblConGoce.Text = "No"
            Me.chkConGoce.Enabled = False
        Else '4 son Permisos a evaluar por Personal
            Me.chkConGoce.Checked = False
            Me.lblConGoce.Text = "No"
        End If

    End Sub

    Protected Sub ddlTipoSolicitud_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlTipoSolicitud.TextChanged
        If Me.ddlTipoSolicitud.SelectedValue <> 4 Then
            calcula_dias()
        End If
        valida_TipoSolicitud()
    End Sub

    Public Sub ConsultarTipoPermiso()
        Try
            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()

            dt = obj.TraerDataTable("sp_Pla_ConsultarTipoPermiso", "TO", categ_permiso)
            obj.CerrarConexion()

            Me.ddlTipoPermiso.DataTextField = "descripcion_Tpp"
            Me.ddlTipoPermiso.DataValueField = "codigo_Tpp"
            Me.ddlTipoPermiso.DataSource = dt
            Me.ddlTipoPermiso.DataBind()

        Catch ex As Exception
            'Me.lblMensaje.Text = "Error al cargar los Tipo de Permiso"
        End Try

    End Sub

    Protected Sub ddlTipoPermiso_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlTipoPermiso.TextChanged
        cod_ST = Me.lblNumero_Tramite.Text
        ConsultarAdjuntos() 'Para que no se pierda el bot+on del grid
    End Sub

    Public Sub calcula_dias()
        Me.lblNum_dias.Text = Str(DateDiff("d", Me.txtDesde.Text, Me.txtHasta.Text) + 1)
    End Sub

    Public Sub calcula_horas()
        'Calcula diferencia de hora y minutos
        Dim cadena As String
        Dim tot_horas As String
        Dim tot_min As Decimal
        Dim dif_hora As String
        Dim position As Integer

        If Me.txtHInicio.Visible And Me.txtHFin.Visible = True Then
            cadena = Str(DateDiff("n", CDate(Me.txtHInicio.Text), CDate(Me.txtHFin.Text)) / 60) 'Ej: 2.25 horas
        ElseIf Me.ddlHoraInicio.Visible = True And Me.ddlHoraFin.Visible = True Then
            cadena = Str(DateDiff("n", CDate(Me.ddlHoraInicio.Text), CDate(Me.ddlHoraFin.Text)) / 60) 'Ej: 2.25 horas
        ElseIf Me.txtHInicio.Visible And Me.ddlHoraFin.Visible Then 'De lo contrario Personal tiene q seleccionar la hora final del permiso personal
            cadena = Str(DateDiff("n", CDate(Me.txtHInicio.Text), CDate(Me.ddlHoraFin.Text)) / 60) 'Ej: 2.25 horas
        ElseIf Me.ddlHoraInicio.Visible = True And Me.txtHFin.Visible = True Then
            cadena = Str(DateDiff("n", CDate(Me.ddlHoraInicio.Text), CDate(Me.txtHFin.Text)) / 60) 'Ej: 2.25 horas
        End If

        If cadena.Length > 2 Then
            position = cadena.IndexOf(".")
            If Val(cadena) < 1 Then
                tot_horas = "0"
            Else
                tot_horas = cadena.Substring(0, position)
            End If

            dif_hora = cadena.Substring(position + 1)

            If dif_hora.Length = 2 Then
                tot_min = dif_hora * 60 * 0.01
            ElseIf dif_hora.Length = 1 Then
                tot_min = dif_hora * 60 * 0.1
            End If
            'tot_min = tot_min.ToString("0.##")

            Me.lblTotalHoras.Text = tot_horas + " h, " + Trim(Str(tot_min)) + " m "
        Else
            Me.lblTotalHoras.Text = cadena + " h"
        End If

    End Sub

    Private Sub registrar_filtros()
        anio = Request.QueryString("anio")
        mes = Request.QueryString("mes")
        estado = Request.QueryString("estado")
        prioridad = Request.QueryString("prioridad")
        tip_sol = Request.QueryString("tip_sol")
        'Response.Write(tip_sol)
    End Sub

    Protected Sub ddlHoraInicio_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlHoraInicio.TextChanged
        Dim vMensaje As String = ""

        If Me.txtHFin.Visible = True Then
            If CDate(Me.ddlHoraInicio.Text) > CDate(Me.txtHFin.Text) Then
                vMensaje = "Aviso : La hora final debe ser mayor que la hora de inicio."
                Dim myscript As String = "alert('" & vMensaje & "')"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                Me.ddlHoraInicio.Text = Me.txtHFin.Text()
                Me.lblTotalHoras.Text = "--"
                Exit Sub
            End If
        Else
            If CDate(Me.ddlHoraInicio.Text) > CDate(Me.ddlHoraFin.Text) Then
                vMensaje = "Aviso : La hora final debe ser mayor que la hora de inicio."
                Dim myscript As String = "alert('" & vMensaje & "')"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                Me.ddlHoraInicio.Text = Me.ddlHoraFin.Text
                Me.lblTotalHoras.Text = "--"
                Exit Sub
            End If
        End If
        calcula_horas()
    End Sub

    Protected Sub ddlHoraFin_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlHoraFin.TextChanged
        Dim vMensaje As String = ""

        If Me.txtHInicio.Visible = True Then
            If CDate(Me.txtHInicio.Text) > CDate(Me.ddlHoraFin.Text) Then
                vMensaje = "Aviso : La hora de inicio debe ser menor que la hora final."
                Dim myscript As String = "alert('" & vMensaje & "')"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                Me.ddlHoraFin.Text = Me.txtHInicio.Text
                Me.lblTotalHoras.Text = "--"
                Exit Sub
            End If
        Else
            If CDate(Me.ddlHoraInicio.Text) > CDate(Me.ddlHoraFin.Text) Then
                vMensaje = "Aviso : La hora de inicio debe ser menor que la hora final."
                Dim myscript As String = "alert('" & vMensaje & "')"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                Me.ddlHoraFin.Text = Me.ddlHoraInicio.Text
                Me.lblTotalHoras.Text = "--"
                Exit Sub
            End If
        End If
        calcula_horas()
    End Sub

    Protected Sub btnCancelar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        registrar_filtros()
        respuesta = "C"
        Response.Redirect("SolicitudesTramitePersonal.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&prioridad=" & prioridad & "&tip_sol=" & tip_sol & "&ctf=" & Me.hdctf.Value & "&respuesta=" & respuesta)
    End Sub

    Private Sub desactiva_controles()

        Me.ddlTipoPermiso.Enabled = False
        Me.txtObservacion.Enabled = False
        Me.txtObservacionPer.Enabled = False
        Me.chkConGoce.Enabled = False
        Me.ddlHoraInicio.Enabled = False
        Me.ddlHoraFin.Enabled = False

        Me.btnAprobar.Enabled = False
        Me.btnRechazar.Enabled = False

    End Sub

    Private Sub carga_horas()

        Dim obj As New clsPersonal
        Dim dts As New Data.DataTable

        dts = obj.ConsultarHorasControl()

        ddlHoraInicio.DataSource = dts
        ddlHoraInicio.DataTextField = "hora"
        ddlHoraInicio.DataValueField = "hora"
        ddlHoraInicio.DataBind()

        ddlHoraFin.DataSource = dts
        ddlHoraFin.DataTextField = "hora"
        ddlHoraFin.DataValueField = "hora"
        ddlHoraFin.DataBind()

        Dim obj1 As New clsPersonal
        Dim dts1 As New Data.DataTable

        dts1 = obj1.ConsultarHorasControl()

        ddlHoraInicioSol.DataSource = dts1
        ddlHoraInicioSol.DataTextField = "hora"
        ddlHoraInicioSol.DataValueField = "hora"
        ddlHoraInicioSol.DataBind()

        ddlHoraFinSol.DataSource = dts1
        ddlHoraFinSol.DataTextField = "hora"
        ddlHoraFinSol.DataValueField = "hora"
        ddlHoraFinSol.DataBind()

    End Sub

    Protected Sub gvCarga_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvCarga.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then

            Dim fila As Data.DataRowView
            fila = e.Row.DataItem

            e.Row.Cells(0).Text = e.Row.RowIndex + 1

            Dim myLink As HyperLink = New HyperLink()
            myLink.NavigateUrl = "javascript:void(0)"
            myLink.Text = "Descargar"
            myLink.CssClass = "btn btn-xs btn-orange"
            myLink.Attributes.Add("onclick", "DescargarArchivo('" & Me.gvCarga.DataKeys(e.Row.RowIndex).Values("ID").ToString & "','" & Me.gvCarga.DataKeys(e.Row.RowIndex).Values("token").ToString & "')")

            e.Row.Cells(3).Controls.Add(myLink)

        End If

    End Sub

    Protected Sub btnAprobar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAprobar.Click
        Me.divFormulario.Visible = False
        Me.divConfirmaAprobar.Visible = True
    End Sub

    Private Sub parteAprobar()

        Dim Fecha_Hora_Ini As DateTime
        Dim Fecha_Hora_Fin As DateTime
        Dim Param As Integer

        Param = Me.ddlTipoSolicitud.SelectedValue

        If Me.txtHInicio.Visible = True Then

            If Param = 4 Then 'Si es Permiso graba la hora de Salida y Retorno real
                Fecha_Hora_Ini = CDate(Me.txtDesde.Text + " " + Me.txtHInicio.Text)
                Fecha_Hora_Fin = CDate(Me.txtHasta.Text + " " + Me.txtHFin.Text)
            Else
                Fecha_Hora_Ini = CDate(Me.txtDesde.Text)
                Fecha_Hora_Fin = CDate(Me.txtHasta.Text)
            End If
        Else

            If Param = 4 Then 'Si es Permiso graba la hora de Salida y Retorno real
                Fecha_Hora_Ini = CDate(Me.txtDesde.Text + " " + ddlHoraInicio.Text)
                Fecha_Hora_Fin = CDate(Me.txtHasta.Text + " " + ddlHoraFin.Text)
            Else
                Fecha_Hora_Ini = CDate(Me.txtDesde.Text)
                Fecha_Hora_Fin = CDate(Me.txtHasta.Text)
            End If
        End If

        Try
            cod_ST = Request.QueryString("cod")

            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            'Response.Write(Session("codigo_ctf"))
            'Se Aprueba la Solicitud Trámite por Personal:
            obj.Ejecutar("AprobacionSolicitudTramite", Me.lblcod_EST.Text, CInt(Session("id_per")), 1, Trim(Me.txtObservacionPer.Text), ddlTipoPermiso.SelectedValue, Me.chkConGoce.Checked, cod_ST, Fecha_Hora_Ini, Fecha_Hora_Fin, "P", "")
            'Se Registra la solicitud en tabla PermisosPersonal: Se modifica Procedimiento, se añade campo codigo_ST
            obj.Ejecutar("sp_Pla_RegistrarPermisosPersonal", Fecha_Hora_Ini, Fecha_Hora_Fin, Trim(txtObservacionPer.Text), Me.lblcodigo_Per.Text, ddlTipoPermiso.SelectedValue, Me.chkConGoce.Checked, "A", 0, 0, Session("id_per"), cod_ST)
            obj.CerrarConexion()

            Me.lblMensaje0.Text = "** AVISO :  La Solicitud se ha aprobado y se ha creado el registro de permiso correctamente"
            respuesta = "A"
            registrar_filtros()
            Response.Redirect("SolicitudesTramitePersonal.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&prioridad=" & prioridad & "&tip_sol=" & tip_sol & "&ctf=" & Me.hdctf.Value & "&respuesta=" & respuesta)

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

        desactiva_controles()

    End Sub

    Protected Sub btnConfirmarAprobarNO_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarAprobarNO.Click
        Me.divFormulario.Visible = True
        Me.divConfirmaAprobar.Visible = False
        Me.lblMensaje0.Text = "** Nota : Operación Cancelada"
        cod_ST = Me.lblNumero_Tramite.Text
        ConsultarAdjuntos() 'Para que no se pierda el bot+on del grid
    End Sub

    Protected Sub btnbtnConfirmarAprobarSI_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarAprobarSI.Click
        Me.divFormulario.Visible = True
        Me.divConfirmaAprobar.Visible = False
        parteAprobar()
    End Sub

    Protected Sub btnRechazar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRechazar.Click
        Me.divFormulario.Visible = False
        Me.divConfirmaRechazar.Visible = True
    End Sub

    Private Sub parteRechazar()

        'Dim observacion As String

        Try
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()

            'cod_ST = Request.QueryString("cod")
            'cod_EST = Request.QueryString("codi")

            obj.Ejecutar("RechazaSolicitudTramite", Val(Me.lblNumero_Tramite.Text), Val(Me.lblcod_EST.Text), CInt(Session("id_per")), Trim(Me.txtObservacionPer.Text))
            Me.lblMensaje0.Text = "** Aviso :  La Solicitud se ha rechazado correctamente"
            obj.CerrarConexion()

            respuesta = "R"
            registrar_filtros()
            Response.Redirect("SolicitudesTramitePersonal.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&prioridad=" & prioridad & "&tip_sol=" & tip_sol & "&ctf=" & Me.hdctf.Value & "&respuesta=" & respuesta)

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

    End Sub

    Protected Sub btnConfirmaRechazarSI_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarRechazarSI.Click
        Me.divFormulario.Visible = True
        Me.divConfirmaRechazar.Visible = False
        parteRechazar()
    End Sub

    Protected Sub btnConfirmarRechazarNO_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarRechazarNO.Click
        Me.divFormulario.Visible = True
        Me.divConfirmaRechazar.Visible = False
        Me.lblMensaje0.Text = "** Nota : Operación Cancelada"
        cod_ST = Me.lblNumero_Tramite.Text
        ConsultarAdjuntos() 'Para que no se pierda el bot+on del grid
    End Sub

    Protected Sub chkConGoce_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkConGoce.CheckedChanged
        If Me.chkConGoce.Checked = True Then
            Me.lblConGoce.Text = "Sí"
        Else
            Me.lblConGoce.Text = "No"
        End If
        cod_ST = Me.lblNumero_Tramite.Text
        ConsultarAdjuntos() 'Para que no se pierda el bot+on del grid
    End Sub

End Class
