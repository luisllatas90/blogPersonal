﻿Partial Class _AprobacionSolicitudTramite
    Inherits System.Web.UI.Page
    Dim cod_ST, cod_EST As Integer
    Dim mes As Integer
    Dim anio, estado, prioridad, tipo_tram, responsable, trabajador As String
    Dim respuesta As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Session("id_per") Is Nothing) Then

            Response.Redirect("http://intranet.usat.edu.pe/campusvirtual/sinacceso.html")

        End If

        If Not IsPostBack Then

            Me.hdid.Value = CInt(Session("id_per")) 'Por sesión
            Me.hdctf.Value = CInt(Session("codigo_ctf"))

            cod_ST = Request.QueryString("cod")
            cod_EST = Request.QueryString("codi")

            registrar_filtros()

            Me.divConfirmaAprobar.Visible = False
            Me.divConfirmaRechazar.Visible = False

            carga_horas()

            Me.txtDesde.Text = DateTime.Now.ToString("dd/MM/yyyy")
            Me.txtHasta.Text = DateTime.Now.ToString("dd/MM/yyyy")

            Me.txtDesde.Text = DateSerial(Now.Date.Year, Now.Month, 1)
            Me.txtHasta.Text = DateSerial(Year(Now.Date), Month(Now.Date) + 1, 0)

            If tipo_tram < 3 Then
                Me.lblTipo_Solic.Text = "Licencia "
                Me.lblTipo_Solic1.text = "Licencia "
            ElseIf tipo_tram = 4 Then
                Me.lblTipo_Solic.Text = "Permiso por Horas "
                Me.lblTipo_Solic1.text = "Permiso por Horas "
            End If

            calcula_dias()

            ConsultarTipoSolicitud()

            ConsultarSolicitudTramite()

            ConsultarAdjuntos()

        End If
    End Sub

    Public Sub ConsultarSolicitudTramite()

        Try

            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos

            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            dt = obj.TraerDataTable("ConsultaSolicitudTramite", cod_ST)
            obj.CerrarConexion()

            Me.lblNumero_Tramite.Text = dt.Rows(0).Item("codigo_ST")
            Me.lblNumero_Tramite1.Text = dt.Rows(0).Item("codigo_ST")
            Me.lblEstado.Text = dt.Rows(0).Item("Estado")
            Me.lblcod_EST.Text = cod_EST

            If dt.Rows(0).Item("Estado") <> "Enviado" Then
                desactiva_controles()
            End If

            If dt.Rows(0).Item("Estado") = "Enviado" Then
                Me.txtFechaEstado.Text = FormatDateTime(dt.Rows(0).Item("fechaEnvio_ST"), DateFormat.GeneralDate)
                Me.nombre_titulo.Text = "Evaluación de "
            Else 'Para Aprobados y Rechazados
                Me.txtFechaEstado.Text = FormatDateTime(dt.Rows(0).Item("Fecha_Evaluacion"), DateFormat.GeneralDate)
                Me.nombre_titulo.Text = "Vista de la "
            End If

            If dt.Rows(0).Item("Prioridad") = "Urgente" Then
                Me.lblprioridad.ForeColor = Drawing.Color.OrangeRed
                Me.lblprioridad.Text = "Urgente"
            Else
                Me.lblprioridad.Text = "Normal"
            End If

            Me.ddlTipoSolicitud.SelectedValue = dt.Rows(0).Item("codigo_TST")
            valida_TipoSolicitud()
            Me.lblColaborador.Text = dt.Rows(0).Item("Colaborador")
            Me.txtMotivo.Text = dt.Rows(0).Item("motivo")

            Me.txtObservacionPersonal.Text = dt.Rows(0).Item("Observacion_Personal") 'Se añadió

            Me.txtDesde.Text = FormatDateTime(dt.Rows(0).Item("fechahoraInicio_ST"), DateFormat.ShortDate)
            Me.txtHasta.Text = FormatDateTime(dt.Rows(0).Item("fechahoraFin_ST"), DateFormat.ShortDate)
            calcula_dias()

            If Me.ddlTipoSolicitud.SelectedValue = 4 Then 'Permiso
                'Me.ddlHoraInicio.Text = CDate(dt.Rows(0).Item("fechahoraInicio_ST")).ToString("MM\/dd\/yyyy")
                'Me.ddlHoraFin.Text = CDate(dt.Rows(0).Item("fechahoraFin_ST")).ToString("HH:mm")
                Me.ddlHoraInicio.Text = FormatDateTime(dt.Rows(0).Item("fechahoraInicio_ST"), DateFormat.ShortTime) 'Extrae solo la Hora
                Me.ddlHoraFin.Text = FormatDateTime(dt.Rows(0).Item("fechahoraFin_ST"), DateFormat.ShortTime) 'Extrae solo la Hora
                calcula_horas()
            End If

            If Me.nombre_titulo.Text = "Vista de la " Then
                Me.ddlHoraInicio.Enabled = False
                Me.ddlHoraFin.Enabled = False
            End If

        Catch ex As Exception
            'Me.lblMensaje.Text = "Error al cargar la Solicitud de Trámite"
        End Try

        ConsultarEvaluacionSolicitud()

    End Sub

    Private Sub ConsultarEvaluacionSolicitud()
        Try
            'Para obtener el campo de observacion del registro:
            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos

            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            dt = obj.TraerDataTable("ConsultaEvaluacionSolicitudTramite", Me.lblcod_EST.Text)
            obj.CerrarConexion()

            If dt.Rows(0).Item("Evaluador") <> CInt(Session("id_per")) Then 'Si es vacío es registro de Personal, sino es de Director
                'Si es diferente significa que Personal lo aprueba por EL Director
                Me.lblPorDirec.Text = "PD"
                Me.txtObservacion.Text = "Aprobación por Director"
            Else
                'Lo está aprobando el Director de Área
                Me.lblPorDirec.Text = "DI"
            End If

            Me.txtObservacion.Text = dt.Rows(0).Item("Observacion")

        Catch ex As Exception
            'Me.lblMensaje.Text = "Error al cargar la Evaluación de Solicitud de Trámite"
        End Try

    End Sub

    Public Sub ConsultarTipoSolicitud()
        Try
            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()

            dt = obj.TraerDataTable("ListaTipoSolicitudTramite", "")
            obj.CerrarConexion()

            Me.ddlTipoSolicitud.DataTextField = "nombre_TST"
            Me.ddlTipoSolicitud.DataValueField = "codigo_TST"
            Me.ddlTipoSolicitud.DataSource = dt
            Me.ddlTipoSolicitud.DataBind()

            valida_TipoSolicitud()

        Catch ex As Exception
            'Me.lblMensaje.Text = "Error al cargar los Tipos de Solicitud Trámite"
        End Try
    End Sub

    Public Sub valida_TipoSolicitud()

        If Me.ddlTipoSolicitud.SelectedValue = 4 Then 'Permisos
            Me.lblHoraFin.Visible = True
            Me.lblHoraInicio.Visible = True
            Me.lblHoras.Visible = True
            Me.lblTotalHoras.Visible = True

            Me.ddlHoraInicio.Visible = True
            Me.ddlHoraFin.Visible = True

            Me.lblNumDias.visible = False
            Me.lblNum_dias.Text = "0"
            Me.lblNum_dias.Visible = False

        Else
            Me.lblTotalHoras.Visible = False
            Me.lblHoraInicio.Visible = False
            Me.lblHoraFin.Visible = False
            Me.lblHoras.Visible = False
            Me.ddlHoraInicio.Visible = False
            Me.ddlHoraFin.Visible = False

        End If
    End Sub

    Public Sub ConsultarAdjuntos()
        Me.gvCarga.DataSource = Nothing
        Me.gvCarga.DataBind()
        Me.celdaGrid.Visible = True
        Me.celdaGrid.InnerHtml = ""

        Try
            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos

            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            dt = obj.TraerDataTable("ConsultaAdjuntoTramite", cod_ST)

            If dt.Rows.Count > 0 Then
                Me.gvCarga.DataSource = dt
                Me.gvCarga.DataBind()

            Else
                Me.gvCarga.DataSource = Nothing
                Me.gvCarga.DataBind()
                Me.celdaGrid.Visible = True
                Me.celdaGrid.InnerHtml = "Aviso: No existen Archivos Adjuntos relacionados"

                Me.lblAdjuntos.Visible = False 'Se añadió

            End If
            obj.CerrarConexion()
        Catch ex As Exception
            Me.lblMensaje0.Text = ex.Message & " - " & ex.StackTrace '"Error al consultar.."
        End Try
    End Sub

    Protected Sub ddlTipoSolicitud_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlTipoSolicitud.TextChanged
        If Me.ddlTipoSolicitud.SelectedValue <> 4 Then
            calcula_dias()
        End If
        valida_TipoSolicitud()
    End Sub

    Public Sub calcula_dias()
        Me.lblNum_dias.Text = Str(DateDiff("d", Me.txtDesde.Text, Me.txtHasta.Text) + 1)
    End Sub

    Public Sub calcula_horas()
        'Calcula diferencia de hora y minutos
        Dim cadena As String
        Dim tot_horas As String
        Dim tot_min As Decimal
        Dim dif_hora As String
        Dim position As Integer

        cadena = Str(DateDiff("n", CDate(Me.ddlHoraInicio.Text), CDate(Me.ddlHoraFin.Text)) / 60) 'Ej: 2.25 horas

        If cadena.Length > 2 Then
            position = cadena.IndexOf(".")
            If Val(cadena) < 1 Then
                tot_horas = "0"
            Else
                tot_horas = cadena.Substring(0, position)
            End If

            dif_hora = cadena.Substring(position + 1)

            If dif_hora.Length = 2 Then
                tot_min = dif_hora * 60 * 0.01
            ElseIf dif_hora.Length = 1 Then
                tot_min = dif_hora * 60 * 0.1
            End If
            'tot_min = tot_min.ToString("0.##")

            Me.lblTotalHoras.Text = tot_horas + " h, " + Trim(Str(tot_min)) + " m "
        Else
            Me.lblTotalHoras.Text = cadena + " h"
        End If

    End Sub

    Private Sub registrar_filtros()
        'Response.Write("responsable: " & Request.QueryString("responsable"))
        anio = Request.QueryString("anio")
        mes = Request.QueryString("mes")
        estado = Request.QueryString("estado")
        prioridad = Request.QueryString("prioridad")
        tipo_tram = Request.QueryString("tipo_tram")
        responsable = Request.QueryString("responsable")
        trabajador = Me.Request.QueryString("trabajador")        
    End Sub

    Protected Sub btnCancelar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        registrar_filtros()
        'respuesta = "C"
        'Response.Write(respuesta)
        If Me.hdctf.Value = 198 Or Me.hdctf.Value = 137 Then 'Si es sesión de Control Linceicas y Permisos o Supervisor de Personal
            Response.Redirect("SolicitudesTramitePorDirector.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&prioridad=" & prioridad & "&tipo_tram=" & tipo_tram & "&responsable=" & responsable & "&trabajador=" & trabajador & "&ctf=" & Me.hdctf.Value & "&respuesta=" & respuesta)
        Else 'Si es sesión de Director
            Response.Redirect("SolicitudesTramiteDirector.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&prioridad=" & prioridad & "&tipo_tram=" & tipo_tram & "&ctf=" & Me.hdctf.Value & "&respuesta=" & respuesta)
        End If

    End Sub

    Private Sub desactiva_controles()

        Me.txtObservacion.Enabled = False

        Me.btnAprobar.Enabled = False
        Me.btnRechazar.Enabled = False

    End Sub

    'Private Sub activa_controles()

    '    Me.ddlTipoSolicitud.Enabled = True
    '    Me.txtDesde.Enabled = True

    '    If Me.ddlTipoSolicitud.SelectedValue = 5 Then
    '        Me.txtHasta.Enabled = False
    '    Else
    '        Me.txtHasta.Enabled = True
    '    End If
    '    Me.txtmotivo.Enabled = True

    '    Me.btnEnviar.Enabled = True

    '    If Me.lblEstado.Text = "Pendiente" Then
    '        Me.btnEnviar.Enabled = True
    '    End If
    '    Me.txtFechaEstado.Visible = True

    '    Me.txtMotivo.Enabled = True
    '    Me.txtObservacion.Enabled = True

    'End Sub
    Private Sub carga_horas()
        Dim obj As New clsPersonal
        Dim dts As New Data.DataTable

        dts = obj.ConsultarHorasControl()

        ddlHoraInicio.DataSource = dts
        ddlHoraInicio.DataTextField = "hora"
        ddlHoraInicio.DataValueField = "hora"
        ddlHoraInicio.DataBind()

        ddlHoraFin.DataSource = dts
        ddlHoraFin.DataTextField = "hora"
        ddlHoraFin.DataValueField = "hora"
        ddlHoraFin.DataBind()
    End Sub

    Protected Sub gvCarga_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvCarga.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then

            Dim fila As Data.DataRowView
            fila = e.Row.DataItem

            e.Row.Cells(0).Text = e.Row.RowIndex + 1

            Dim myLink As HyperLink = New HyperLink()
            myLink.NavigateUrl = "javascript:void(0)"
            myLink.Text = "Descargar"
            myLink.CssClass = "btn btn-xs btn-orange"
            myLink.Attributes.Add("onclick", "DescargarArchivo('" & Me.gvCarga.DataKeys(e.Row.RowIndex).Values("ID").ToString & "','" & Me.gvCarga.DataKeys(e.Row.RowIndex).Values("token").ToString & "')")

            e.Row.Cells(3).Controls.Add(myLink)

        End If

    End Sub

    Protected Sub btnAprobar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAprobar.Click
        Me.divFormulario.Visible = False
        Me.divConfirmaAprobar.Visible = True
    End Sub

    Private Sub parteAprobar()

        Dim Fecha_Hora_Ini As DateTime
        Dim Fecha_Hora_Fin As DateTime
        Dim Param As Integer

        Param = Me.ddlTipoSolicitud.SelectedValue

        If Param = 4 Then 'Permiso
            Fecha_Hora_Ini = CDate(Me.txtDesde.Text + " " + ddlHoraInicio.Text)
            Fecha_Hora_Fin = CDate(Me.txtHasta.Text + " " + ddlHoraFin.Text)
        Else
            Fecha_Hora_Ini = CDate(Me.txtDesde.Text)
            Fecha_Hora_Fin = CDate(Me.txtHasta.Text)
        End If

        'If Me.txtObservacion.Text = "" Then
        '    Me.lblMensaje0.Text = "* ATENCIÓN: Debe indicar una Observación"
        '    Exit Sub
        'End If

        Try
            cod_ST = Request.QueryString("cod")
            cod_EST = Request.QueryString("codi")

            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            'Response.Write(Session("codigo_ctf"))

            obj.Ejecutar("AprobacionSolicitudTramite", cod_EST, CInt(Session("id_per")), 1, Trim(Me.txtObservacion.Text), 0, 0, cod_ST, Fecha_Hora_Ini, Fecha_Hora_Fin, "D", Me.lblPorDirec.Text) 'Se registra la respuesta
            obj.Ejecutar("CreaEvaluacionSolicitudTramite", cod_ST, "P") 'Se crea el registro en la tabla EvaluaciónSolicitudTramite para Personal

            obj.CerrarConexion()

            Me.lblMensaje0.Text = "** AVISO :  LA SOLICITUD SE HA APROBADO Y ENVIADO CORRECTAMENTE A PERSONAL"
            respuesta = "A"
            registrar_filtros()

            If Me.hdctf.Value = 198 Or Me.hdctf.Value = 137 Then 'Si es sesión de Control Linceicas y Permisos o Supervisor de Personal
                Response.Redirect("SolicitudesTramitePorDirector.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&prioridad=" & prioridad & "&tipo_tram=" & tipo_tram & "&responsable=" & responsable & "&trabajador=" & trabajador & "&ctf=" & Me.hdctf.Value & "&respuesta=" & respuesta)
            Else 'Si es sesión de Director
                Response.Redirect("SolicitudesTramiteDirector.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&prioridad=" & prioridad & "&tipo_tram=" & tipo_tram & "&ctf=" & Me.hdctf.Value & "&respuesta=" & respuesta)
            End If

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

        desactiva_controles()

    End Sub

    Protected Sub btnConfirmarAprobarNO_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarAprobarNO.Click
        Me.divFormulario.Visible = True
        Me.divConfirmaAprobar.Visible = False
        Me.lblMensaje0.Text = "** Nota : Operación Cancelada"

    End Sub

    Protected Sub btnbtnConfirmarAprobarSI_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarAprobarSI.Click
        Me.divFormulario.Visible = True
        Me.divConfirmaAprobar.Visible = False
        parteAprobar()
    End Sub

    Protected Sub btnRechazar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRechazar.Click
        Me.divFormulario.Visible = False
        Me.divConfirmaRechazar.Visible = True
    End Sub

    Private Sub parteRechazar()

        Dim observacion As String

        Try
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()

            'cod_ST = Request.QueryString("cod")
            'cod_EST = Request.QueryString("codi")

            If Me.txtObservacion.Text = "" Then
                Me.lblMensaje0.Text = "* ATENCIÓN: Debe indicar una Observación"
                Exit Sub
            End If

            observacion = Trim(Me.txtObservacion.Text)

            obj.Ejecutar("RechazaSolicitudTramite", Val(Me.lblNumero_Tramite.Text), Val(Me.lblcod_EST.Text), Me.hdid.Value, observacion)
            Me.lblMensaje0.Text = "** AVISO :  LA SOLICITUD SE HA RECHAZADO CORRECTAMENTE"
            obj.CerrarConexion()

            respuesta = "R"
            registrar_filtros()

            If Me.hdctf.Value = 198 Or Me.hdctf.Value = 137 Then 'Si es sesión de Control Linceicas y Permisos o Supervisor de Personal
                Response.Redirect("SolicitudesTramitePorDirector.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&prioridad=" & prioridad & "&tipo_tram=" & tipo_tram & "&responsable=" & responsable & "&trabajador=" & trabajador & "&ctf=" & Me.hdctf.Value & "&respuesta=" & respuesta)
            Else 'Si es sesión de Director
                Response.Redirect("SolicitudesTramiteDirector.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&prioridad=" & prioridad & "&tipo_tram=" & tipo_tram & "&ctf=" & Me.hdctf.Value & "&respuesta=" & respuesta)
            End If

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

    End Sub

    Protected Sub btnConfirmaRechazarSI_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarRechazarSI.Click
        Me.divFormulario.Visible = True
        Me.divConfirmaRechazar.Visible = False
        parteRechazar()
    End Sub

    Protected Sub btnConfirmaRechazarNO_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarRechazarNO.Click
        Me.divFormulario.Visible = True
        Me.divConfirmaRechazar.Visible = False
        Me.lblMensaje0.Text = "** Nota : Operación Cancelada"
        cod_ST = Me.lblNumero_Tramite.Text
        ConsultarAdjuntos() 'Para que no se pierda el bot+on del grid
    End Sub

    Protected Sub txtDesde_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDesde.TextChanged
        Dim vMensaje As String = ""
        If CDate(Me.txtDesde.Text) < Today Then 'Si la fecha de inicio es menor a la fecha de Hoy
            vMensaje = "Aviso : La fecha de inicio debe ser mayor o igual a la fecha actual"
            Dim myscript As String = "alert('" & vMensaje & "')"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
            Me.txtDesde.Text = Today
        End If

        If Me.ddlTipoSolicitud.SelectedValue = 4 Then
            Me.txtHasta.Text = Me.txtDesde.Text
        Else
            If CDate(Me.txtDesde.Text) > CDate(Me.txtHasta.Text) Then
                vMensaje = "Aviso : La fecha de inicio debe ser menor o igual que la fecha final."
                Dim myscript As String = "alert('" & vMensaje & "')"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                Me.txtHasta.Text = Me.txtDesde.Text
                calcula_dias()
                Exit Sub
            End If
            calcula_dias()
        End If
    End Sub

    Protected Sub txtHasta_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtHasta.TextChanged
        Dim vMensaje As String = ""
        If CDate(Me.txtHasta.Text) < Today Then 'Si la fecha de inicio es menor a la fecha de Hoy
            vMensaje = "Aviso : La fecha de fin debe ser mayor o igual a la fecha actual"
            Dim myscript As String = "alert('" & vMensaje & "')"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
            Me.txtHasta.Text = Today
        End If
        If CDate(Me.txtDesde.Text) > CDate(Me.txtHasta.Text) Then
            vMensaje = "Aviso : La fecha final debe ser mayor o igual que la fecha de inicio."
            Dim myscript As String = "alert('" & vMensaje & "')"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
            Me.txtHasta.Text = Me.txtDesde.Text
            calcula_dias()
            Exit Sub
        End If
        calcula_dias()
    End Sub

    Protected Sub HoraInicio_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlHoraInicio.TextChanged
        Dim vMensaje As String = ""
        If CDate(Me.ddlHoraInicio.Text) > CDate(Me.ddlHoraFin.Text) Then
            vMensaje = "Aviso : La hora final debe ser mayor que la hora de inicio."
            Dim myscript As String = "alert('" & vMensaje & "')"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
            Me.ddlHoraInicio.Text = Me.ddlHoraFin.Text
            calcula_horas()
            Exit Sub
        End If
        calcula_horas()
    End Sub

    Protected Sub HoraFin_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlHoraFin.TextChanged
        Dim vMensaje As String = ""
        If CDate(Me.ddlHoraInicio.Text) > CDate(Me.ddlHoraFin.Text) Then
            vMensaje = "Aviso : La hora de inicio debe ser menor que la hora final."
            Dim myscript As String = "alert('" & vMensaje & "')"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
            Me.ddlHoraFin.Text = Me.ddlHoraInicio.Text
            calcula_horas()
            Exit Sub
        End If
        calcula_horas()
    End Sub

End Class
