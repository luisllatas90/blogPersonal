﻿Partial Class _SolicitudesTramite
    Inherits System.Web.UI.Page
    Dim tip_Per As Integer
    Dim anio, mes As Integer
    Dim estado As String
    Dim j As Integer
    Dim respuesta As String
    Dim cod_ST As Integer

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Session("id_per") Is Nothing) Then

            Response.Redirect("http://intranet.usat.edu.pe/campusvirtual/sinacceso.html")

        End If

        If Not IsPostBack Then

            'Me.hdctf.Value = CInt(Request.QueryString("ctf"))

            If Request.QueryString("anio") <> "" Then
                Me.ddlAño.SelectedValue = Request.QueryString("anio")
            End If
            If Request.QueryString("mes") <> "" Then
                Me.ddlMes.SelectedValue = Request.QueryString("mes")
            End If
            If Request.QueryString("estado") <> "" Then
                Me.ddlEstado.SelectedValue = Request.QueryString("estado")
            End If
            If Request.QueryString("respuesta") <> "" Then
                respuesta = Request.QueryString("respuesta")
            End If

            Me.divConfirmaEliminar.Visible = False
            Me.divConfirmaEnviar.Visible = False

            lblMensaje.Visible = False 'Se añadió

            ConsultarSolicitudes()

            valida_respuesta()

        End If
    End Sub

    Private Sub valida_respuesta()
        If respuesta = "G" Then
            Me.lblMensaje0.Text = "*NOTA : La Solicitud de Trámite se ha Guardado Correctamente"
        ElseIf respuesta = "M" Then
            Me.lblMensaje0.Text = "*NOTA : La Solicitud de Trámite se ha Modificado Correctamente"
        ElseIf respuesta = "GE" Then
            Me.lblMensaje0.Text = "*NOTA : La Solicitud de Trámite se ha Guardado y Enviado correctamente"
        ElseIf respuesta = "C" Then
            Me.lblMensaje0.Text = "** NOTA : Operación CANCELADA"
        ElseIf respuesta = "NG" Then
            Me.lblMensaje0.Text = "*Nota : No se Pudo Guardar la Solicitud de Trámite"
        ElseIf respuesta = "NE" Then
            Me.lblMensaje0.Text = "*NOTA: Error de Envío de la Solicitud de Trámite"
        End If
    End Sub

    Public Sub ConsultarSolicitudes()

        Me.gvCarga.DataSource = Nothing
        Me.gvCarga.DataBind()
        'Me.celdaGrid.Visible = True
        'Me.celdaGrid.InnerHtml = ""

        registrar_filtros()
        j = 0

        Try
            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos

            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            dt = obj.TraerDataTable("ListaSolicitudTramite", anio, mes, CInt(Session("id_per")), estado)

            If dt.Rows.Count > 0 Then
                Me.gvCarga.DataSource = dt
                Me.gvCarga.DataBind()
            Else
                Me.gvCarga.DataSource = Nothing
                Me.gvCarga.DataBind()
                'Me.celdaGrid.Visible = True
                'Me.celdaGrid.InnerHtml = "** AVISO :  NO EXISTEN SOLICITUDES CON LOS PARÁMETROS SELECCIONADOS"
                lblMensaje.Visible = True
                Me.lblMensaje.Text = "** AVISO :  No Existen Solicitudes con los Parámetros seleccionados"

                Me.btnEditar.Enabled = False
                Me.btnEliminar.Enabled = False
                Me.btnEnviar.Enabled = False

            End If
            obj.CerrarConexion()

            'Me.gvCarga.DataSource = Nothing
            'Me.gvCarga.DataBind()
            'Me.celdaGrid.Visible = True

        Catch ex As Exception
            Me.lblMensaje.Text = ex.Message & " - " & ex.StackTrace '"Error al consultar.."
        End Try

    End Sub

    Protected Sub cboAño_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlAño.SelectedIndexChanged
        ConsultarSolicitudes()
        Me.lblMensaje0.Text = ""
    End Sub

    Protected Sub cboMes_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlMes.SelectedIndexChanged
        ConsultarSolicitudes()
        Me.lblMensaje0.Text = ""
    End Sub

    Protected Sub cboEstado_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlEstado.SelectedIndexChanged
        ConsultarSolicitudes()
        Me.lblMensaje0.Text = ""
    End Sub

    Protected Sub gvCarga_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvCarga.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim fila As Data.DataRowView
            fila = e.Row.DataItem

            'Dim chk As CheckBox = CType(e.Row.FindControl("CheckBox1"), CheckBox)
            'chk.Visible = False
            'e.Row.Cells(1).Text = e.Row.RowIndex + 1

            Dim cod As Integer
            cod = fila.Row("codigo_ST")

            'e.Row.Attributes.Add("OnMouseOver", "Resaltar(1,this,'S')")
            'e.Row.Attributes.Add("OnMouseOut", "Resaltar(0,this,'S')")
            CType(e.Row.FindControl("CheckBox1"), CheckBox).Attributes.Add("OnClick", "PintarFilaMarcada(this.parentNode.parentNode,this.checked)")

            'If e.Row.Cells(2).Text <> "Permiso" Then
            '    FormatDateTime(CDate(e.Row.Cells(4).Text), DateFormat.LongDate)
            'End If

            'e.Row.Cells(4).Style("FormatDateTime") = IIf(fila.Row("Tipo_Solicitud") <> "Permiso", DateFormat.ShortDate, DateFormat.GeneralDate)

            If e.Row.Cells(3).Text = "Urgente" Then
                e.Row.Cells(3).Font.Bold = False
                e.Row.Cells(3).ForeColor = System.Drawing.Color.Blue
                'e.Row.Cells(3).Attributes.Add("HyperLink", "../SolicitudTramite.aspx")
            End If

            ' ''Para Mostrar Evaluador
            'Dim dt As New Data.DataTable
            'Dim obj As New ClsConectarDatos

            'obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            'obj.AbrirConexion()
            'dt = obj.TraerDataTable("EvaluadorSolicitudTramite", cod_ST)
            'obj.CerrarConexion()
            'e.Row.Cells(10).Text = IIf(fila.Row("codigoPer_EST") = "", "AREA DE PERSONAL", dt.Rows(0).Item("Evaluador"))

            e.Row.Cells(12).ForeColor = IIf(fila.Row("Estado") = "Generado", Drawing.Color.Red, Drawing.Color.Blue)
            e.Row.Cells(12).Font.Underline = IIf(fila.Row("Estado") <> "Generado", True, False)
            Dim pagina As String = "<a href='SolicitudTramite.aspx?cod=" & cod & "&anio=" & anio & "&mes=" & mes & "&estado=" & estado & "'>" & e.Row.Cells(12).Text & "</a>"
            'e.Row.Cells(11).Text = IIf(fila.Row("Estado") <> "Generado", "<a href='SolicitudTramite.aspx?cod=" + cod + "'>" + e.Row.Cells(11).Text + "</a>", e.Row.Cells(11).Text)
            e.Row.Cells(12).Text = IIf(fila.Row("Estado") <> "Generado", pagina, e.Row.Cells(12).Text)

            If fila.Row("Estado") <> "Generado" Then
                e.Row.Cells(0).Text = ""
            Else
                j = j + 1
            End If

            If j >= 1 Then
                Me.btnEditar.Enabled = True
                Me.btnEliminar.Enabled = True
                Me.btnEnviar.Enabled = True
            ElseIf j = 0 Then
                Me.btnEditar.Enabled = False
                Me.btnEliminar.Enabled = False
                Me.btnEnviar.Enabled = False
            End If

            'e.Row.Cells(11).Text = "<a href='www.google.com.pe'>Estado</a>"
            'If e.Row.Cells(10).Text = "Enviado" Then
            '    e.Row.Cells(10).Font.Bold = True
            '    e.Row.Cells(10).Font.Underline = True
            '    'e.Row.FindControl("CheckBox1").Visible = False
            'Else
            '    e.Row.Cells(10).Font.Bold = True
            '    e.Row.Cells(10).Font.Underline = True
            '    e.Row.Cells(10).ForeColor = System.Drawing.Color.Blue
            '    'e.Row.Enabled = False
            '    'e.Row.Cells(0).FindControl("CheckBox1").Visible = False
            'End If
            'CType(e.Row.FindControl("CheckBox1"), CheckBox).Attributes.Add("OnClick", "PintarFilaMarcada(this.parentNode.parentNode,this.checked)")
        End If
    End Sub

    Private Sub EnviarAPagina(ByVal pagina As String)
        Me.btnEditar.Attributes("src") = pagina & "&id=" & Request.QueryString("id") & "&ctf=" & Request.QueryString("ctf") '& "&cco=" & Me.cboCecos.SelectedValue
    End Sub

    Protected Sub btnNuevo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNuevo.Click
        Response.Redirect("SolicitudTramite.aspx")
    End Sub

    Private Sub registrar_filtros()

        'Session("Filtromes") = Me.ddlMes.SelectedValue
        'Session("Filtroanio") = Me.ddlAño.SelectedValue
        'Session("Filtroestado") = Me.ddlEstado.SelectedValue
        anio = Me.ddlAño.SelectedValue
        mes = Me.ddlMes.SelectedValue
        estado = Me.ddlEstado.SelectedValue

    End Sub

    Protected Sub btnEditar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEditar.Click

        Dim vMensaje As String

        registrar_filtros()

        Dim Fila As GridViewRow
        Try
            Dim x As Integer
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            x = 0
            For i As Integer = 0 To Me.gvCarga.Rows.Count - 1
                Fila = Me.gvCarga.Rows(i)
                If Fila.RowType = DataControlRowType.DataRow Then
                    If CType(Fila.FindControl("CheckBox1"), CheckBox).Checked = True Then
                        'Response.Write(gvCarga.DataKeys.Item(Fila.RowIndex).Values("Estado"))
                        Dim cod As Integer
                        cod = gvCarga.DataKeys.Item(Fila.RowIndex).Values("codigo_ST")

                        If gvCarga.DataKeys.Item(Fila.RowIndex).Values("Estado") = "Generado" Then
                            'Response.Write(cod)
                            Response.Redirect("SolicitudTramite.aspx?cod=" & cod & "&anio=" & anio & "&mes=" & mes & "&estado=" & estado)
                            'Response.Write("SolicitudTramite.aspx?cod=" & cod)
                        Else
                            Me.lblMensaje0.Text = "* NOTA : LA SOLICITUD DE TRÁMITE YA SE HA ENVIADO Y NO SE PUEDE MODIFICAR"
                        End If
                    Else
                        x = x + 1
                    End If
                End If
            Next
            If x = Me.gvCarga.Rows.Count Then
                vMensaje = "*Aviso : Debe seleccionar un registro de la lista"
                Dim myscript As String = "alert('" & vMensaje & "')"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                Exit Sub
                ConsultarSolicitudes()
            End If
            obj.CerrarConexion()

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

    End Sub

    Protected Sub btnEnviar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEnviar.Click

        Dim vMensaje As String

        Dim Fila As GridViewRow
        Try
            Dim x As Integer
            x = 0
            For i As Integer = 0 To Me.gvCarga.Rows.Count - 1
                Fila = Me.gvCarga.Rows(i)
                If Fila.RowType = DataControlRowType.DataRow Then
                    If CType(Fila.FindControl("CheckBox1"), CheckBox).Checked = True Then
                        Me.divListado.Visible = False
                        Me.divConfirmaEnviar.Visible = True
                    Else
                        x = x + 1
                    End If
                End If
            Next
            If x = Me.gvCarga.Rows.Count Then
                vMensaje = "*Aviso : Debe seleccionar un registro de la lista"
                Dim myscript As String = "alert('" & vMensaje & "')"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                Exit Sub
                ConsultarSolicitudes()
            End If
        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

    End Sub

    Private Sub parteEnviar()

        Dim rptta As Integer
        Dim vMensaje As String = ""
        Dim Fila As GridViewRow

        Try
            'Dim obj As New ClsConectarDatos
            'obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            'obj.AbrirConexion()
            Dim x As Integer
            x = 0
            For i As Integer = 0 To Me.gvCarga.Rows.Count - 1
                Fila = Me.gvCarga.Rows(i)
                If Fila.RowType = DataControlRowType.DataRow Then
                    If CType(Fila.FindControl("CheckBox1"), CheckBox).Checked = True Then
                        cod_ST = gvCarga.DataKeys.Item(Fila.RowIndex).Values("codigo_ST")
                        'gvCarga.DataKeys.Item(Fila.RowIndex).Values("Estado") = "Enviado" Then
                        If gvCarga.DataKeys.Item(Fila.RowIndex).Values("Estado") = "Generado" Then

                            'obj.CerrarConexion()

                            Dim ObjCnx As New ClsSqlServer(ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString)
                            rptta = ObjCnx.TraerValor("CreaEvaluacionSolicitudTramite", cod_ST, "D") 'Se crea el registro en la tabla EvaluaciónSolicitudTramite para el Director

                            If rptta = 0 Then
                                vMensaje = "Aviso : No existe un Director asignado a su Centro de Costo"
                                Dim myscript As String = "alert('" & vMensaje & "')"
                                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                                Me.lblMensaje0.Text = "** AVISO :  NO SE HA ENVIADO LA SOLICITUD DE TRÁMITE"
                                Exit Sub
                            Else
                                ObjCnx.Ejecutar("EnviarSolicitudTramite", cod_ST) 'Procedimiento para Enviar al Director  
                                Me.lblMensaje0.Text = "** AVISO :  LA SOLICITUD SE HA ENVIADO CORRECTAMENTE"
                            End If
                        Else
                            Me.lblMensaje0.Text = "** NOTA :  LA SOLICTUD DE TRÁMITE YA SE HA ENVIADO"
                        End If

                        Else
                            x = x + 1
                        End If

                End If
            Next

            If x = Me.gvCarga.Rows.Count Then
                Me.lblMensaje0.Text = "** NOTA : DEBE SELECCIONAR UN REGISTRO DE LA LISTA"
            End If

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

        ConsultarSolicitudes()

    End Sub

    Protected Sub btnEliminar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEliminar.Click

        Dim vMensaje As String

        Dim Fila As GridViewRow

        Try
            Dim x As Integer
            x = 0
            For i As Integer = 0 To Me.gvCarga.Rows.Count - 1
                Fila = Me.gvCarga.Rows(i)
                If Fila.RowType = DataControlRowType.DataRow Then
                    If CType(Fila.FindControl("CheckBox1"), CheckBox).Checked = True Then
                        Me.divListado.Visible = False
                        Me.divConfirmaEliminar.Visible = True
                    Else
                        x = x + 1
                    End If
                End If
            Next
            If x = Me.gvCarga.Rows.Count Then
                vMensaje = "*Aviso : Debe seleccionar un registro de la lista"
                Dim myscript As String = "alert('" & vMensaje & "')"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                Exit Sub
                ConsultarSolicitudes()
            End If
        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

    End Sub

    Private Sub parteEliminar()
        Dim Fila As GridViewRow
        Try
            Dim x As Integer
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            x = 0

            For i As Integer = 0 To Me.gvCarga.Rows.Count - 1
                Fila = Me.gvCarga.Rows(i)
                If Fila.RowType = DataControlRowType.DataRow Then
                    If CType(Fila.FindControl("CheckBox1"), CheckBox).Checked = True Then
                        obj.Ejecutar("EliminaSolicitudTramite", gvCarga.DataKeys.Item(Fila.RowIndex).Values("codigo_ST"))
                        Me.lblMensaje0.Text = "** AVISO :  LA SOLICITUD SE HA ELIMINADO CORRECTAMENTE"
                    Else
                        x = x + 1
                    End If
                End If
            Next
            If x = Me.gvCarga.Rows.Count Then
                Me.lblMensaje0.Text = "** NOTA : DEBE SELECCIONAR UN REGISTRO DE LA LISTA"
            End If
            obj.CerrarConexion()

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

        ConsultarSolicitudes()

    End Sub

    'Private Sub CargaMeses()
    '    Me.ddlMes.Items.Add("TODOS")
    '    Me.ddlMes.Items.Add("Enero")
    '    Me.ddlMes.Items.Add("Febrero")
    '    Me.ddlMes.Items.Add("Marzo")
    '    Me.ddlMes.Items.Add("Abril")
    '    Me.ddlMes.Items.Add("Mayo")
    '    Me.ddlMes.Items.Add("Junio")
    '    Me.ddlMes.Items.Add("Julio")
    '    Me.ddlMes.Items.Add("Agosto")
    '    Me.ddlMes.Items.Add("Setiembre")
    '    Me.ddlMes.Items.Add("Octubre")
    '    Me.ddlMes.Items.Add("Noviembre")
    '    Me.ddlMes.Items.Add("Diciembre")
    'End Sub

    Protected Sub btnConfirmarEnviarSI_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmaEnviarSI.Click
        Me.divListado.Visible = True
        Me.divConfirmaEnviar.Visible = False
        parteEnviar()
    End Sub

    Protected Sub btnConfirmarEnviarNO_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmaEnviarNO.Click
        Me.divListado.Visible = True
        Me.divConfirmaEnviar.Visible = False
        ConsultarSolicitudes()
        respuesta = "C"
        valida_respuesta()
    End Sub

    Protected Sub btnConfirmarEliminarSI_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarEliminarSI.Click
        Me.divListado.Visible = True
        Me.divConfirmaEliminar.Visible = False
        parteEliminar()
    End Sub

    Protected Sub btnConfirmarEliminarNO_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarEliminarNO.Click
        Me.divListado.Visible = True
        Me.divConfirmaEliminar.Visible = False
        ConsultarSolicitudes()
        respuesta = "C"
        valida_respuesta()
    End Sub

    Protected Sub gvCarga_SelectedIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewSelectEventArgs) Handles gvCarga.SelectedIndexChanging
        Me.btnEnviar.Enabled = True
        Me.btnEditar.Enabled = True
        Me.btnEliminar.Enabled = True
    End Sub

End Class
