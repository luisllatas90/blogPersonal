﻿Imports System.Collections.Generic
Imports System.IO
Imports System.Xml

Partial Class _SolicitudTramite
    Inherits System.Web.UI.Page
    Dim cod_ST As Integer
    Dim anio, mes As Integer
    Dim estado As String
    Dim respuesta As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If (Session("id_per") Is Nothing) Then
            Response.Redirect("http://intranet.usat.edu.pe/campusvirtual/sinacceso.html")
        End If

        If Not IsPostBack Then

            cod_ST = Request.QueryString("cod")
            'Response.Write(cod_ST)

            'Me.divConfirmaGuardar.Visible = False
            'Me.divConfirmaGuadarEnviar.Visible = False

            carga_horas()

            Me.txtDesde.Text = DateTime.Now.ToString("dd/MM/yyyy")
            Me.txtHasta.Text = DateTime.Now.ToString("dd/MM/yyyy")

            Me.txtDesde.Text = DateSerial(Now.Date.Year, Now.Month, Now.Day)
            Me.txtHasta.Text = DateSerial(Year(Now.Date), Month(Now.Date) + 1, 0)

            calcula_dias()

            ConsultarTipoSolicitud()

            ConsultarSolicitudTramite()

            ConsultarAdjuntos()

            If Me.lblEstado.Text = "Rechazado" Or Me.lblEstado.Text = "Enviado" Or Me.lblEstado.Text = "Aprobado Director" Or Me.lblEstado.Text = "Aprobado Personal" Then
                desactiva_controles()
            ElseIf Me.lblEstado.Text = "Nuevo" Or Me.lblEstado.Text = "Generado" Then
                activa_controles()

                If Me.lblEstado.Text = "Nuevo" Then
                    txtFechaEstado.Visible = False
                End If

            End If

            valida_aviso()

            Dim objcrm As New ClsCRM
            'Me.btnAdjunto.Attributes.Add("OnClick", "javascript:ModalAdjuntar2('" & objcrm.EncrytedString64(Trim(Me.lblNumero_Tramite.Text)) & "')")
            'Me.btnAdjunto.Attributes.Add("OnClick", "javascript:ModalAdjuntar2('" & objcrm.EncrytedString64(Trim(Me.lblNumero_Tramite.Text)) & "')")
            'Me.btnAdjunto.Attributes.Add("OnClick", "javascript:ModalAdjuntar2('" & Me.lblNumero_Tramite.Text & "')")

        End If
    End Sub

    Public Sub ConsultarSolicitudTramite()

        Try
            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos

            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            dt = obj.TraerDataTable("ConsultaSolicitudTramite", cod_ST)
            obj.CerrarConexion()

            'Me.lblNumero_Tramite.Font.Italic = IIf(cod_ST <> "", True, False)
            Me.lblNumero_Tramite.Text = dt.Rows(0).Item("codigo_ST")
            Me.lblNumero_Tramite1.Text = dt.Rows(0).Item("codigo_ST")

            Me.lblEstado.Text = dt.Rows(0).Item("Estado")

            If dt.Rows(0).Item("Estado") <> "Generado" Then
                Me.btnGuardar.Enabled = False
                Me.btnGuardarEnviar.Enabled = False
            End If

            If dt.Rows(0).Item("Estado") = "Enviado" Then
                Me.txtFechaEstado.Text = FormatDateTime(dt.Rows(0).Item("fechaEnvio_ST"), DateFormat.GeneralDate)
                Me.nombre_titulo.Text = "Vista de "
                Me.files.Enabled = False
            ElseIf dt.Rows(0).Item("Estado") = "Generado" Then 'Si es Generado es porque se va a Editar
                Me.txtFechaEstado.Text = FormatDateTime(dt.Rows(0).Item("fechaActualizacion_ST"), DateFormat.GeneralDate)
                Me.nombre_titulo.Text = "Actualización de "
            Else 'Para Aprobados
                Me.txtFechaEstado.Text = FormatDateTime(dt.Rows(0).Item("Fecha_Evaluacion"), DateFormat.GeneralDate)
                Me.nombre_titulo.Text = "Vista de "
                Me.files.Enabled = False
            End If

            If dt.Rows(0).Item("Prioridad") = "Urgente" Then
                Me.ddlPrioridad.ForeColor = Drawing.Color.OrangeRed
                Me.ddlPrioridad.SelectedIndex = 1 'Urgente
            Else
                Me.ddlPrioridad.SelectedIndex = 0 'Normal
            End If

            Me.ddlTipoSolicitud.SelectedValue = dt.Rows(0).Item("codigo_TST")
            Me.txtmotivo.Text = dt.Rows(0).Item("motivo")

            Me.txtDesde.Text = FormatDateTime(dt.Rows(0).Item("fechahoraInicio_ST"), DateFormat.ShortDate)
            Me.txtHasta.Text = FormatDateTime(dt.Rows(0).Item("fechahoraFin_ST"), DateFormat.ShortDate)
            calcula_dias()

            Me.txtObservacion.Text = dt.Rows(0).Item("Observacion_Director") 'Se añadió
            Me.txtObservacionPersonal.Text = dt.Rows(0).Item("Observacion_Personal") 'Se añadió

            If Me.ddlTipoSolicitud.SelectedValue = 4 Then 'Permiso
                'Me.ddlHoraInicio.Text = CDate(dt.Rows(0).Item("fechahoraInicio_ST")).ToString("MM\/dd\/yyyy")
                'Me.ddlHoraFin.Text = CDate(dt.Rows(0).Item("fechahoraFin_ST")).ToString("HH:mm")
                Me.ddlHoraInicio.Text = FormatDateTime(dt.Rows(0).Item("fechahoraInicio_ST"), DateFormat.ShortTime) 'Extrae solo la Hora
                Me.ddlHoraFin.Text = FormatDateTime(dt.Rows(0).Item("fechahoraFin_ST"), DateFormat.ShortTime) 'Extrae solo la Hora
                calcula_horas()
            End If

            valida_TipoSolicitud()

            If Me.lblEstado.Text = "Nuevo" Then
                txtFechaEstado.Visible = False
            Else
                txtFechaEstado.Visible = True
            End If

        Catch ex As Exception
            'Me.lblMensaje0.Text = "Error al cargar la Solicitud de Trámite"
        End Try

    End Sub

    Public Sub ConsultarTipoSolicitud()
        Try
            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()

            dt = obj.TraerDataTable("ListaTipoSolicitudTramite", "")
            obj.CerrarConexion()

            Me.ddlTipoSolicitud.DataTextField = "nombre_TST"
            Me.ddlTipoSolicitud.DataValueField = "codigo_TST"
            Me.ddlTipoSolicitud.DataSource = dt
            Me.ddlTipoSolicitud.DataBind()

            valida_TipoSolicitud()

        Catch ex As Exception
            Me.lblMensaje0.Text = "Error al cargar los Tipos de Solicitud Trámite"
        End Try
    End Sub

    Private Sub valida_aviso()
        If Me.ddlTipoSolicitud.SelectedValue = 2 Then 'Licencia C/G
            Me.lblAviso.Visible = True
            Me.lblEnfermedad.Visible = True
        Else
            Me.lblAviso.Visible = False
            Me.lblEnfermedad.Visible = False
        End If
    End Sub

    Public Sub ConsultarAdjuntos()
        Me.gvCarga.DataSource = Nothing
        Me.gvCarga.DataBind()
        Me.celdaGrid.Visible = True
        Me.celdaGrid.InnerHtml = ""

        Try
            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos

            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            dt = obj.TraerDataTable("ConsultaAdjuntoTramite", cod_ST)

            If dt.Rows.Count > 0 Then
                Me.gvCarga.DataSource = dt
                Me.gvCarga.DataBind()
                hddEliminar.Value = True
            Else
                Me.gvCarga.DataSource = Nothing
                Me.gvCarga.DataBind()
                Me.celdaGrid.Visible = True
                Me.celdaGrid.InnerHtml = "Aviso: No existen Archivos Adjuntos relacionados"
                hddEliminar.Value = False

                If Me.lblEstado.Text <> "Nuevo" Then
                    Me.lblAdjuntos.Visible = False 'Se añadió
                End If

            End If
                obj.CerrarConexion()
        Catch ex As Exception
            Me.lblMensaje0.Text = ex.Message & " - " & ex.StackTrace '"Error al consultar.."
        End Try
    End Sub

    Private Sub registrar_filtros()
        anio = Request.QueryString("anio")
        mes = Request.QueryString("mes")
        estado = Request.QueryString("estado")
    End Sub

    'Protected Sub btnGuardar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGuardar.Click
    '    Me.divFormulario.Visible = False
    '    Me.divConfirmaGuadar.Visible = True
    'End Sub

    Private Sub parteGuardar()

        valida_sesion()

        Dim vMensaje As String = ""
        Dim Fecha_Hora_Ini As DateTime
        Dim Fecha_Hora_Fin As DateTime
        Dim Param, rptta As Integer

        Param = Me.ddlTipoSolicitud.SelectedValue

        If Param = 4 Then 'Permiso
            'Dim vHoraInicio As DateTime = ddlHoraInicio.Text
            'Dim vHoraFin As DateTime = ddlHoraFin.Text
            Fecha_Hora_Ini = CDate(Me.txtDesde.Text + " " + ddlHoraInicio.Text)
            Fecha_Hora_Fin = CDate(Me.txtHasta.Text + " " + ddlHoraFin.Text)
        Else
            Fecha_Hora_Ini = CDate(Me.txtDesde.Text)
            Fecha_Hora_Fin = CDate(Me.txtHasta.Text)
        End If

        If Me.ddlTipoSolicitud.SelectedIndex < 0 Then
            Me.lblMensaje0.Text = "* ATENCIÓN: Debe seleccionar un Tipo de Solicitud de Trámite"
            Exit Sub
        End If

        If Trim(Me.txtmotivo.Text) = "" Then
            Me.lblMensaje0.Text = "* ATENCIÓN: Debe indicar el motivo de la Solicitud de Trámite"
            Exit Sub
        End If

        Try
            'Dim obj As New ClsConectarDatos
            'obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            Dim ObjCnx As New ClsSqlServer(ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString)
            Dim dt As New Data.DataTable
            'obj.AbrirConexion()

            If Me.lblEstado.Text = "Nuevo" Then
                'Dim dt As New Data.DataTable

                dt = ObjCnx.TraerDataTable("ComparaSolicitudTramite", CInt(Session("id_per")), Fecha_Hora_Ini, Fecha_Hora_Fin, Param, 0)
                If dt.Rows.Count > 0 Then
                    vMensaje = "Aviso : Ud. ya tiene una o más Solicitudes de Trámite en el rango de Fechas solicitadas"
                    Dim myscript As String = "alert('" & vMensaje & "')"
                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                    Exit Sub
                End If
                'obj.Ejecutar("GuardarSolicitudTramite", Me.ddlTipoSolicitud.SelectedValue, Fecha_Hora_Ini, Fecha_Hora_Fin, Trim(txtmotivo.Text), Me.ddlPrioridad.SelectedValue, CInt(Session("id_per")), "G")
                'Se considera el cod_ST a crear
                cod_ST = ObjCnx.TraerValor("GuardarSolicitudTramite", Me.ddlTipoSolicitud.SelectedValue, Fecha_Hora_Ini, Fecha_Hora_Fin, Trim(txtmotivo.Text), Me.ddlPrioridad.SelectedValue, CInt(Session("id_per")), "G")

                If cod_ST = 0 Then
                    respuesta = "NG"
                    Me.lblMensaje0.Text = "*Nota : No se Pudo Guardar la Solicitud de Trámite"
                ElseIf cod_ST > 0 Then
                    GuardarArchivos(cod_ST)
                    If Me.files.HasFile Then
                        ObjCnx.Ejecutar("InsertaArchivosSolicitudTramite", cod_ST, CInt(Session("id_per")))
                    End If
                    Me.lblMensaje0.Text = "*Nota : La Solicitud de Trámite se ha guardado correctamente"
                    respuesta = "G"
                End If                
                registrar_filtros()
                Response.Redirect("SolicitudesTramite.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&respuesta=" & respuesta)

            Else
				cod_ST = Request.QueryString("cod")
				'Dim dt As New Data.DataTable
				dt = ObjCnx.TraerDataTable("ComparaSolicitudTramite", CInt(Session("id_per")), Fecha_Hora_Ini, Fecha_Hora_Fin, Param, cod_ST)
				If dt.Rows.Count > 0 Then
					vMensaje = "Aviso : Existen Solicitudes de Trámite en las Fechas/Horas solicitadas"
					Dim myscript As String = "alert('" & vMensaje & "')"
					Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
					Exit Sub
				End If
                rptta = ObjCnx.TraerValor("ActualizaSolicitudTramite", Me.ddlTipoSolicitud.SelectedValue, Fecha_Hora_Ini, Fecha_Hora_Fin, Trim(txtmotivo.Text), Me.ddlPrioridad.SelectedValue, "G", cod_ST)
                If rptta = 1 Then
                    GuardarArchivos(cod_ST)
                    If Me.files.HasFile Then
                        ObjCnx.Ejecutar("InsertaArchivosSolicitudTramite", cod_ST, CInt(Session("id_per"))) 'Inserta en la tabla ArchivosSolictudTramite
                    End If
                    Me.lblMensaje0.Text = "*Nota : La Solicitud de Trámite se ha Modificado Correctamente"
                    respuesta = "M"
                Else
                    respuesta = "NM"
                    Me.lblMensaje0.Text = "*Nota : No se Pudo Actualizar la Solicitud de Trámite"
                End If

                registrar_filtros()
                Response.Redirect("SolicitudesTramite.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&respuesta=" & respuesta)

            End If
            'obj.CerrarConexion()

        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try
        'Response.Redirect("SolicitudesTramite.aspx")
        'ConsultarSolicitudTramite()
    End Sub

    'Protected Sub btnConfirmarGuardarNO_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarGuardarNO.Click
    '    Me.divFormulario.Visible = True
    '    Me.divConfirmaGuardar.Visible = False
    'End Sub

    Protected Sub btnConfirmarGuardarSI_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarGuardarSI.Click
        Me.divFormulario.Visible = True
        'Me.divConfirmaGuadar.Visible = False
        parteGuardar()
    End Sub

    'Protected Sub btnGuardarEnviar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnGuardarEnviar.Click
    '    Me.divFormulario.Visible = False
    '    Me.divConfirmaGuadarEnviar.Visible = True
    'End Sub

    Private Sub parteGuardarEnviar()

        valida_sesion()

        Dim vMensaje As String = ""
        Dim Fecha_Hora_Ini As DateTime
        Dim Fecha_Hora_Fin As DateTime
        Dim Param, rptta As Integer

        Param = Me.ddlTipoSolicitud.SelectedValue

        If Param = 4 Then 'Permisos
            'Dim vHoraInicio As DateTime = ddlHoraInicio.Text
            'Dim vHoraFin As DateTime = ddlHoraFin.Text
            Fecha_Hora_Ini = CDate(Me.txtDesde.Text + " " + ddlHoraInicio.Text)
            Fecha_Hora_Fin = CDate(Me.txtHasta.Text + " " + ddlHoraFin.Text)
        Else
            Fecha_Hora_Ini = CDate(Me.txtDesde.Text)
            Fecha_Hora_Fin = CDate(Me.txtHasta.Text)
        End If

        If Me.ddlTipoSolicitud.SelectedIndex < 0 Then
            vMensaje = "Aviso : Atención: Debe seleccionar un Tipo de Solicitud de Trámite"
            Dim myscript As String = "alert('" & vMensaje & "')"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
            Exit Sub            
        End If

        Try
            '-------guardar solicitud
            Dim ObjCnx As New ClsSqlServer(ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString)
            Dim dt As New Data.DataTable

            cod_ST = Request.QueryString("cod")

            If cod_ST = 0 Then 'Para Nuevas Solicitudes

                dt = ObjCnx.TraerDataTable("ComparaSolicitudTramite", CInt(Session("id_per")), Fecha_Hora_Ini, Fecha_Hora_Fin, Param, 0)
                If dt.Rows.Count > 0 Then
                    vMensaje = "Aviso : Ud. ya tiene una o más Solicitudes de Trámite en el rango de Fechas solicitadas"
                    Dim myscript As String = "alert('" & vMensaje & "')"
                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                    Exit Sub
                End If
                'Se considera el cod_ST a crear
                cod_ST = ObjCnx.TraerValor("GuardarSolicitudTramite", Me.ddlTipoSolicitud.SelectedValue, Fecha_Hora_Ini, Fecha_Hora_Fin, Trim(txtmotivo.Text), Me.ddlPrioridad.SelectedValue, CInt(Session("id_per")), "G")
                If cod_ST > 0 Then
                    GuardarArchivos(cod_ST)
                    If Me.files.HasFile Then
                        ObjCnx.Ejecutar("InsertaArchivosSolicitudTramite", cod_ST, CInt(Session("id_per")))
                    End If
                    Me.lblMensaje0.Text = "*Nota : La Solicitud de Trámite se ha guardado correctamente"
                    respuesta = "G"
                End If
            End If
            '-------guardar solicitud

            '-------enviar a director
            If cod_ST = 0 Then
                respuesta = "NG"
                Me.lblMensaje0.Text = "*Nota : No se Pudo Guardar la Solicitud de Trámite"

            Else
                dt = ObjCnx.TraerDataTable("ComparaSolicitudTramite", CInt(Session("id_per")), Fecha_Hora_Ini, Fecha_Hora_Fin, Param, cod_ST)

                If dt.Rows.Count > 0 Then
                    vMensaje = "Aviso : Existen Solicitudes de Trámite en las Fechas/Horas solicitadas"
                    Dim myscript As String = "alert('" & vMensaje & "')"
                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                    Exit Sub
                End If

                rptta = ObjCnx.TraerValor("CreaEvaluacionSolicitudTramite", cod_ST, "D")

                If rptta = 0 Then
                    vMensaje = "Aviso : No existe un Director asignado a su Centro de Costo. Consultar con el Área de Personal"
                    Dim myscript As String = "alert('" & vMensaje & "')"
                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                    Me.lblMensaje0.Text = "** AVISO :  Se ha Guardado su Solicitud de Trámite pero No se ha Enviado"
                    respuesta = "NE"
                    Me.btnCancelar.enabled = True
                    'btnGuardar.visible = False
                    'btnGuardarEnviar.visible = False
                    ConsultarSolicitudTramite()
                    Exit Sub
                ElseIf rptta = -1 Then
                    vMensaje = "Aviso : Existe más de un Director asignado a su Centro de Costo. Por favor Consultar con el Área de Personal"
                    Dim myscript As String = "alert('" & vMensaje & "')"
                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                    Me.lblMensaje0.Text = "** AVISO :  Se ha Guardado su Solicitud de Trámite pero No se ha Enviado"
                    respuesta = "NE"
                    Me.btnCancelar.Enabled = True
                    'btnGuardar.Visible = False
                    'btnGuardarEnviar.Visible = False
                    ConsultarSolicitudTramite()
                    Exit Sub
                Else                    
                    'Si entra en esta parte ya se creó el registro de Director en tabla: Evaluacion
                    Dim ObjCnx1 As New ClsSqlServer(ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString)
                    rptta = ObjCnx1.TraerValor("ActualizaSolicitudTramite", Me.ddlTipoSolicitud.SelectedValue, Fecha_Hora_Ini, Fecha_Hora_Fin, Trim(txtmotivo.Text), Me.ddlPrioridad.SelectedValue, "E", cod_ST)

                    If rptta = 1 Then
                        If respuesta = "G" Then
                            'No inserta archivos porq ya insertó arriba
                        Else
                            GuardarArchivos(cod_ST)
                            If Me.files.HasFile Then
                                ObjCnx1.Ejecutar("InsertaArchivosSolicitudTramite", cod_ST, CInt(Session("id_per"))) 'Inserta en la tabla ArchivosSolictudTramite
                            End If
                        End If

                        Me.lblMensaje0.Text = "*Nota : La Solicitud de Trámite se ha Guardado y Enviado Correctamente"
                        respuesta = "GE"
                    Else                        
                        Me.lblMensaje0.Text = "*Nota : Error de Envío de la Solicitud de Trámite"
                        respuesta = "NE"
                    End If

                End If
            End If

            registrar_filtros()

            Response.Redirect("SolicitudesTramite.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&respuesta=" & respuesta)
            '-------enviar a director
        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try

        desactiva_controles()

    End Sub

    'Protected Sub btnConfirmarGuardarEnviarNO_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarGuardarEnviarNO.Click
    '    Me.divFormulario.Visible = True
    '    Me.divConfirmaGuardarEnviar.Visible = False
    'End Sub

    Protected Sub btnConfirmarGuardarEnviarSI_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmarGuardarEnviarSI.Click
        Me.divFormulario.Visible = True
        'Me.divConfirmaGuadarEnviar.Visible = False
        parteGuardarEnviar()
    End Sub

    Public Sub valida_TipoSolicitud()
        If Me.ddlTipoSolicitud.SelectedValue = 4 Then 'Permisos
            Me.lblHoraFin.Visible = True
            Me.lblHoraInicio.Visible = True
            Me.lblHoras.Visible = True
            Me.ddlHoraInicio.Visible = True
            Me.ddlHoraFin.Visible = True
            Me.lblTotalHoras.Visible = True

            Me.txtDesde.Enabled = True
            Me.txtHasta.Text = Me.txtDesde.Text
            Me.txtHasta.Enabled = False

            Me.lblNumDias.visible = False
            Me.lblNum_dias.Text = "0"
            Me.lblNum_dias.visible = False
        Else
            Me.lblTotalHoras.Visible = False
            Me.lblHoraInicio.Visible = False
            Me.lblHoraFin.Visible = False
            Me.lblHoras.Visible = False
            Me.ddlHoraInicio.Visible = False
            Me.ddlHoraFin.Visible = False

            Me.txtDesde.Enabled = True
            Me.txtHasta.Enabled = True                      

        End If
    End Sub

    Protected Sub ddlTipoSolicitud_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlTipoSolicitud.TextChanged
        If Me.ddlTipoSolicitud.SelectedValue <> 4 Then
            calcula_dias()
        End If
        valida_aviso()
        valida_TipoSolicitud()
        lista_adjuntos()
    End Sub

    Protected Sub cboPrioridad_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlPrioridad.SelectedIndexChanged
        If Me.ddlPrioridad.SelectedIndex = 1 Then 'Urgente
            Me.ddlPrioridad.ForeColor = Drawing.Color.OrangeRed
        Else 'Normal
            Me.ddlPrioridad.ForeColor = Drawing.Color.Black
        End If
        lista_adjuntos()
    End Sub

    Public Sub calcula_dias()
        Me.lblNum_dias.Text = Str(DateDiff("d", Me.txtDesde.Text, Me.txtHasta.Text) + 1)
    End Sub

    Public Sub calcula_horas()
        'Calcula diferencia de hora y minutos
        Dim cadena As String
        Dim tot_horas As String
        Dim tot_min As Decimal
        Dim dif_hora As String
        Dim position As Integer

        cadena = Str(DateDiff("n", CDate(Me.ddlHoraInicio.Text), CDate(Me.ddlHoraFin.Text)) / 60) 'Ej: 2.25 horas

        If cadena.Length > 2 Then
            position = cadena.IndexOf(".")
            If Val(cadena) < 1 Then
                tot_horas = "0"
            Else
                tot_horas = cadena.Substring(0, position)
            End If

            dif_hora = cadena.Substring(position + 1)

            If dif_hora.Length = 2 Then
                tot_min = dif_hora * 60 * 0.01
            ElseIf dif_hora.Length = 1 Then
                tot_min = dif_hora * 60 * 0.1
            End If
            'tot_min = tot_min.ToString("0.##")
            Me.lblTotalHoras.Text = tot_horas + " h, " + Trim(Str(tot_min)) + " m "
        Else
            Me.lblTotalHoras.Text = cadena + " h"
        End If

    End Sub

    Protected Sub gvCarga_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gvCarga.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then

            Dim fila As Data.DataRowView
            fila = e.Row.DataItem

            e.Row.Cells(0).Text = e.Row.RowIndex + 1

            'Aquí abajo desactivo la opción Eliminar archivo
            If Me.lblEstado.Text = "Rechazado" Or Me.lblEstado.Text = "Enviado" Or Me.lblEstado.Text = "Aprobado Director" Or Me.lblEstado.Text = "Aprobado Personal" Then                
                Me.gvcarga.columns(4).visible = False
                'e.Row.Cells(4).Visible = False
            End If

            Dim myLink As HyperLink = New HyperLink()
            myLink.NavigateUrl = "javascript:void(0)"
            myLink.Text = "Descargar"
            myLink.CssClass = "btn btn-xs btn-orange"
            myLink.Attributes.Add("onclick", "DescargarArchivo('" & Me.gvCarga.DataKeys(e.Row.RowIndex).Values("ID").ToString & "','" & Me.gvCarga.DataKeys(e.Row.RowIndex).Values("token").ToString & "')")

            e.Row.Cells(3).Controls.Add(myLink)
            'CType(e.Row.FindControl("CheckBox1"), CheckBox).Attributes.Add("OnClick", "PintarFilaMarcada(this.parentNode.parentNode,this.checked)")

        End If

    End Sub

    Protected Sub gvCarga_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles gvCarga.RowDeleting
        Try
            Dim obj As New ClsSqlServer(ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString)
            Dim mensaje As String

            If hddEliminar.Value = True Then
                mensaje = obj.Ejecutar("EliminaAdjuntoTramite", gvCarga.DataKeys(e.RowIndex).Values("codigo_ast"), CInt(Session("id_per")))
                'Me.divMensaje.InnerHtml = Me.divMensaje.InnerHtml + "<span style='color:green'><i class='ion-checkmark-round'></i> " + "Archivo eliminado.." + " </span><br>"
                lista_adjuntos()

                Me.celdaGrid.Visible = True
                Me.celdaGrid.InnerHtml = "Aviso : Archivo eliminado correctamente.."

                obj = Nothing
                e.Cancel = True
                'ScriptManager.RegisterStartupScript(Me.fraDetalleGrupoHorario, "string".GetType(), "EliminarArchivo", "alert('Eliminado: " & mensaje & "');", True)
            Else
                'ScriptManager.RegisterStartupScript(Me.fraDetalleGrupoHorario, "string".GetType(), "EliminarProgramacion2", "alert('No puede eliminar el curso programado porque la fecha de programación académica ha concluido');", True)
            End If
        Catch ex As Exception
            Response.Write(ex.Message & " - " & ex.StackTrace)
        End Try
    End Sub

    Protected Sub txtDesde_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtDesde.TextChanged
        Dim vMensaje As String = ""
        If CDate(Me.txtDesde.Text) < Today Then 'Si la fecha de inicio es menor a la fecha de Hoy
            vMensaje = "Aviso : La fecha de inicio debe ser mayor o igual a la fecha actual"
            Dim myscript As String = "alert('" & vMensaje & "')"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
            Me.txtDesde.Text = Today
        End If

        If Me.ddlTipoSolicitud.SelectedValue = 4 Then
            Me.txtHasta.Text = Me.txtDesde.Text
        Else
            If CDate(Me.txtDesde.Text) > CDate(Me.txtHasta.Text) Then
                vMensaje = "Aviso : La fecha de inicio debe ser menor o igual que la fecha final."
                Dim myscript As String = "alert('" & vMensaje & "')"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
                Me.txtHasta.Text = Me.txtDesde.Text
                calcula_dias()
                lista_adjuntos()
                Exit Sub
            End If
            calcula_dias()            
        End If
        lista_adjuntos()
    End Sub

    Protected Sub txtHasta_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtHasta.TextChanged
        Dim vMensaje As String = ""
        If CDate(Me.txtHasta.Text) < Today Then 'Si la fecha de inicio es menor a la fecha de Hoy
            vMensaje = "Aviso : La fecha de fin debe ser mayor o igual a la fecha actual"
            Dim myscript As String = "alert('" & vMensaje & "')"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
            Me.txtHasta.Text = Today
        End If
        If CDate(Me.txtDesde.Text) > CDate(Me.txtHasta.Text) Then
            vMensaje = "Aviso : La fecha final debe ser mayor o igual que la fecha de inicio."
            Dim myscript As String = "alert('" & vMensaje & "')"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
            Me.txtHasta.Text = Me.txtDesde.Text
            calcula_dias()
            lista_adjuntos()
            Exit Sub
        End If
        calcula_dias()
        lista_adjuntos()
    End Sub

    Protected Sub HoraInicio_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlHoraInicio.TextChanged
        Dim vMensaje As String = ""
        If CDate(Me.ddlHoraInicio.Text) > CDate(Me.ddlHoraFin.Text) Then
            vMensaje = "Aviso : La hora final debe ser mayor que la hora de inicio."
            Dim myscript As String = "alert('" & vMensaje & "')"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
            Me.ddlHoraFin.Text = Me.ddlHoraInicio.Text
            calcula_horas()
            lista_adjuntos()
            Exit Sub
        End If
        calcula_horas()
        lista_adjuntos()
    End Sub

    Protected Sub HoraFin_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlHoraFin.TextChanged
        Dim vMensaje As String = ""
        If CDate(Me.ddlHoraInicio.Text) > CDate(Me.ddlHoraFin.Text) Then
            vMensaje = "Aviso : La hora de inicio debe ser menor que la hora final."
            Dim myscript As String = "alert('" & vMensaje & "')"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "myscript", myscript, True)
            Me.ddlHoraFin.Text = Me.ddlHoraInicio.Text
            calcula_horas()
            lista_adjuntos()
            Exit Sub
        End If
        calcula_horas()
        lista_adjuntos()
    End Sub

    Protected Sub btnCancelar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        registrar_filtros()
        respuesta = "C"
        Response.Redirect("SolicitudesTramite.aspx?anio=" & anio & "&mes=" & mes & "&estado=" & estado & "&respuesta=" & respuesta)
    End Sub

    Private Sub desactiva_controles()

        Me.ddlPrioridad.Enabled = False
        Me.ddlTipoSolicitud.Enabled = False
        Me.txtDesde.Enabled = False
        Me.txtHasta.Enabled = False
        Me.txtmotivo.Enabled = False
        Me.ddlHoraInicio.Enabled = False
        Me.ddlHoraFin.Enabled = False

        Me.btnGuardar.visible = False
        Me.btnGuardarEnviar.Visible = False

        Me.files.Visible = False 'Se añadió

        Me.lbladjunto1.Visible = False
        Me.lbladjunto2.visible = False

    End Sub

    Private Sub activa_controles()

        Me.ddlPrioridad.Enabled = True
        Me.ddlTipoSolicitud.Enabled = True
        Me.txtDesde.Enabled = True

        If Me.ddlTipoSolicitud.SelectedValue = 4 Then
            Me.txtHasta.Enabled = False
        Else
            Me.txtHasta.Enabled = True
        End If

        Me.txtmotivo.Enabled = True

        Me.btnGuardar.visible = True
        Me.btnGuardarEnviar.visible = True
        Me.lbladjunto1.visible = True
        Me.lbladjunto2.Visible = True

        Me.lblAdjuntos.Visible = True 'Se añadió
        Me.txtFechaEstado.Visible = True 'Se añadió

    End Sub

    Private Sub carga_horas()
        Dim obj As New clsPersonal
        Dim dts As New Data.DataTable

        dts = obj.ConsultarHorasControl()

        ddlHoraInicio.DataSource = dts
        ddlHoraInicio.DataTextField = "hora"
        ddlHoraInicio.DataValueField = "hora"
        ddlHoraInicio.DataBind()

        ddlHoraFin.DataSource = dts
        ddlHoraFin.DataTextField = "hora"
        ddlHoraFin.DataValueField = "hora"
        ddlHoraFin.DataBind()
    End Sub

    Private Sub lista_adjuntos()
        cod_ST = Request.QueryString("cod")
        ConsultarAdjuntos() 'Se añade para q no se pierda el botón de la lista del grid
    End Sub

    Private Sub valida_sesion()

        If CInt(Session("id_per")) = Nothing Then
            Me.lblMensaje0.Text = "*ATENCIÓN : SU SESIÓN HA CADUCADO"
        End If

        Me.gvCarga.DataSource = Nothing
        Me.gvCarga.DataBind()
        Me.celdaGrid.Visible = True
        Me.celdaGrid.InnerHtml = ""

    End Sub

    Private ruta As String = "http://serverdev/campusvirtual/ArchivosCompartidos/SharedFiles.asmx" ' Serverdev
    'Private ruta As String = "http://localhost/campusvirtual/ArchivosCompartidos/SharedFiles.asmx" ' Producción

    Function SubirArchivo(ByVal id_tabla As Integer, ByVal nro_transaccion As String, ByVal ArchivoaSubir As HttpPostedFile, ByVal tipo As String, ByVal usuario_per As Integer) As String
        Try
            Dim codigo_tablaArchivo As String = id_tabla ' ID de tablaArchivo
            Dim archivo As HttpPostedFile = ArchivoaSubir
            Dim nro_operacion As String = ""
            Dim id_tablaProviene As String = nro_transaccion

            Dim Fecha As String = Date.Now.ToString("dd/MM/yyyy")
            Dim Usuario As String = Session("perlogin").ToString
            Dim Input(archivo.ContentLength) As Byte

            Dim b As New BinaryReader(archivo.InputStream)
            Dim binData As Byte() = b.ReadBytes(archivo.InputStream.Length)
            Dim base64 = System.Convert.ToBase64String(binData)

            Dim wsCloud As New ClsArchivosCompartidos
            Dim list As New Dictionary(Of String, String)

            Dim nombre_archivo As String = System.IO.Path.GetFileName(archivo.FileName.Replace("&", "_").Replace("'", "_").Replace("*", "_"))

            list.Add("Fecha", Fecha)
            list.Add("Extencion", System.IO.Path.GetExtension(archivo.FileName))
            list.Add("Nombre", nombre_archivo)
            list.Add("TransaccionId", id_tablaProviene)
            list.Add("TablaId", codigo_tablaArchivo)
            list.Add("NroOperacion", nro_operacion)
            list.Add("Archivo", System.Convert.ToBase64String(binData, 0, binData.Length))
            list.Add("Usuario", Usuario)
            list.Add("Equipo", "")
            list.Add("Ip", "")
            list.Add("param8", Usuario)

            Dim envelope As String = wsCloud.SoapEnvelope(list)
            Dim result As String = wsCloud.PeticionRequestSoap(ruta, envelope, "http://usat.edu.pe/UploadFile", Session("perlogin").ToString)
            Return result
        Catch ex As Exception
            Dim Data1 As New Dictionary(Of String, Object)()
            Dim serializer As System.Web.Script.Serialization.JavaScriptSerializer = New System.Web.Script.Serialization.JavaScriptSerializer()
            Dim JSONresult As String = ""
            Dim list As New List(Of Dictionary(Of String, Object))()
            Data1.Add("rpta", "1 - SUBIR ARCHIVO")
            Data1.Add("msje", ex.Message)
            list.Add(Data1)
            JSONresult = serializer.Serialize(list)
            Response.Write(JSONresult)
            Return JSONresult
        End Try
    End Function

    Protected Sub GuardarArchivos(ByVal codigo_ST As Integer)
        'Me.divMensaje.InnerHtml = ""
        'Me.divMensaje.Attributes.Remove("Class")
        Response.Write("<script type='javascript'>alert('GUARDAR ARCHIVO')</script>")
        Dim idtabla As Integer = 13
        Dim codigo_per As Integer = Session("id_per")
        Try
            If Me.files.HasFile Then
                Response.Write("<script type='javascript'>alert('ENCONTRO ARCHIVO')</script>")
                'permite .jpg, .jpeg, .pdf o .rar
                Dim ExtensionesPermitidas As String() = {".jpg", ".jpeg", ".pdf", ".rar"}
                Dim valida As Integer = 0
                Dim Archivos As HttpFileCollection = Request.Files
                For j As Integer = 0 To Archivos.Count - 1
                    For i As Integer = 0 To ExtensionesPermitidas.Length - 1
                        If Path.GetExtension(Archivos(j).FileName) = ExtensionesPermitidas(i) Then
                            'Response.Write(Path.GetExtension(Archivos(j).FileName) + " - " + ExtensionesPermitidas(i) + "<br>")
                            valida = valida + 1
                        End If
                        If Archivos(j).ContentLength < 2048 Then
                            valida = valida + 1
                        End If
                    Next
                Next

                If valida = Archivos.Count Then 'si todos los archivos tienen formato y peso permitido subimos los archivos, sino NO.
                    Response.Write("<script type='javascript'>alert('PASO VALIDACION')</script>")

                    Dim respuesta As String = ""
                    For i As Integer = 0 To Archivos.Count - 1
                        respuesta = SubirArchivo(idtabla, codigo_ST, Archivos(i), 0, codigo_per)
                        If respuesta.Contains("Registro procesado correctamente") Then
                            'Me.divMensaje.InnerHtml = Me.divMensaje.InnerHtml + "<span style='color:green'><i class='ion-checkmark-round'></i> Archivo Adjuntado Correctamente : " + Archivos(i).FileName.ToString + " </span><br>"
                        Else
                            'Me.divMensaje.InnerHtml = Me.divMensaje.InnerHtml + "<span style='color:red'><i class='ion-close-round'></i> No se Pudo Adjuntar Archivo : " + Archivos(i).FileName.ToString + " ,Verifique Extensión y Tamaño máximo(2MB). </span><br> "
                        End If
                    Next
                    'Me.divMensaje.Attributes.Add("Class", "alert alert-success")
                Else
                    'Me.divMensaje.InnerHtml = "Solo se aceptan tipos de archivo con extension '.jpg','.jpeg','.pdf','.rar'"
                    'Me.divMensaje.Attributes.Add("Class", "alert alert-danger")
                End If
            Else
                'Me.divMensaje.InnerHtml = "Seleccione al menos un archivo para Adjuntar."
                'Me.divMensaje.Attributes.Add("Class", "alert alert-danger")
            End If
        Catch ex As Exception			
			Response.Write("<script type='javascript'>alert('" & ex.message & "')</script>")
            'Me.divMensaje.InnerHtml = "Los Archivos no se pudieron Subir: " & ex.Message
            'Me.divMensaje.Attributes.Add("Class", "alert alert-danger")

        End Try
    End Sub

End Class
