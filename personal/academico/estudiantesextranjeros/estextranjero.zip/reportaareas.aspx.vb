﻿
Partial Class librerianet_estudiantesextranjeros_reportaareas
    Inherits System.Web.UI.Page

End Class
