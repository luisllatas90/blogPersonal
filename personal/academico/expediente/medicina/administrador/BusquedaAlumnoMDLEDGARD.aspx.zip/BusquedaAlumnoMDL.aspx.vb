﻿Imports System.Security.Cryptography



Partial Class medicina_administrador_BusquedaAlumno


    Inherits System.Web.UI.Page
    Dim cod_alu As Int32
    Dim nombres As String
    Dim test As Integer

    'Protected Sub DdlBusqueda_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DdlBusqueda.SelectedIndexChanged
    '    If Me.DdlBusqueda.SelectedValue = 1 Then
    '        Me.TxtBusqueda.MaxLength = 10
    '    Else
    '        Me.TxtBusqueda.MaxLength = 50
    '    End If
    'End Sub

    Public Enum MessageType
        Success
        [Error]
        Info
        Warning
    End Enum
    Protected Sub btnActualizarLista_click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnActualizarLista.Click
        mt_listarAsistenciaAv()
    End Sub
    Protected Sub GridAsistenciaAV_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridAsistenciaAV.PreRender
        If GridAsistenciaAV.Rows.Count > 0 Then
            GridAsistenciaAV.UseAccessibleHeader = True
            GridAsistenciaAV.HeaderRow.TableSection = TableRowSection.TableHeader
        End If
    End Sub
    Protected Sub CmdBuscar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CmdBuscar.Click
        Dim obj As New ClsConectarDatos
        obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
        obj.AbrirConexion()
        'If Me.DdlBusqueda.SelectedValue = 1 Then
        If Me.TxtBusqueda.Text.Trim <> "" Then
            'Me.GridAlumnos.DataSource = obj.TraerDataTable("ConsultarAlumnoRptAsistenciasNotas", Me.TxtBusqueda.Text.Trim, CInt(Request.QueryString("mod").ToString.Substring(0, 1)))
            'Response.Write("ConsultarAlumnoRptAsistenciasNotas '" & Me.TxtBusqueda.Text.Trim & "'," & Request.QueryString("mod"))
            Me.GridAlumnos.DataSource = obj.TraerDataTable("ConsultarAlumnoRptAsistenciasNotas", Me.TxtBusqueda.Text.Trim, Request.QueryString("mod"))
        End If
        obj.CerrarConexion()
        Me.GridAlumnos.DataBind()
        If GridAlumnos.Rows.Count > 0 Then
            Me.GridAlumnos.Focus()
        Else
            Me.TxtBusqueda.Focus()
        End If

    End Sub

    Protected Sub btnCancelar_click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Me.pnlLista.Visible = True
        Me.pnlAsistenciaAV.Visible = False
        Me.GridAsistenciaAV.DataSource = Nothing
        Me.GridAsistenciaAV.DataBind()
        Me.dvtitulo.InnerHtml = ""
    End Sub

    Private Sub mt_listarAsistenciaAv()
        Try

     
            Dim dt As New Data.DataTable
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            dt = obj.TraerDataTable("ConsultarAlumnoRptAsistenciasNotasAV", "1", CInt(Desencriptar(Me.HdPso.Value)), CInt(Me.hdCac.Value))
            obj.CerrarConexion()
            Me.GridAsistenciaAV.DataSource = dt
            Me.GridAsistenciaAV.DataBind()
        Catch ex As Exception
            Call mt_ShowMessage(ex.Message.Replace("'", ""), MessageType.Error)
        End Try
    End Sub
    Protected Sub GridAlumnos_RowCommand(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewCommandEventArgs) Handles GridAlumnos.RowCommand
        Try

            Dim index As Integer = Convert.ToInt32(e.CommandArgument)
            If (e.CommandName = "AsistenciaAV") Then

                Me.pnlLista.Visible = False
                Me.pnlAsistenciaAV.Visible = True

                Dim titulo As String = ""
                titulo = "<ul>"
                titulo = titulo & "<li><b>COD. UNIVERSITARIO:</b> " & GridAlumnos.DataKeys(index).Values("codigoUniver_alu").ToString() & "</li>"
                titulo = titulo & "<li><b>ESTUDIANTE:</b> " & GridAlumnos.DataKeys(index).Values("alumno").ToString() & "</li>"
                titulo = titulo & "<li><b>CARRERA PROFESIONAL:</b> " & GridAlumnos.DataKeys(index).Values("nombre_cpf").ToString() & "</li>"
                titulo = titulo & "<li><b>SEMESTRE ACADÉMICO:</b> " & Me.DdlCicloAcad.SelectedItem.Text.ToString & "</li>"
                titulo = titulo & "</ul>"
                Me.dvtitulo.InnerHtml = titulo.ToString

                Me.HdPso.Value = Encriptar(GridAlumnos.DataKeys(index).Values("codigo_pso").ToString)
                Me.hdCac.Value = fnDevuelveNumEntero(Me.DdlCicloAcad.SelectedValue)



                mt_listarAsistenciaAv()

            End If


        Catch ex As Exception
            Call mt_ShowMessage(ex.Message, MessageType.Error)
        End Try
    End Sub

    Protected Sub GridAlumnos_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles GridAlumnos.RowDataBound

        If e.Row.RowType = DataControlRowType.Header Then
            If fnAdministradorSistema() Or fnEsDirectorAcademico() Or fnEsCoordinadorDA() Then
                e.Row.Cells(8).Visible = True

            Else
                e.Row.Cells(8).Visible = False
            End If

        End If

        If e.Row.RowType = DataControlRowType.DataRow Then


            Dim fila As Data.DataRowView
            fila = e.Row.DataItem
            e.Row.Attributes.Add("OnMouseOver", "Resaltar(1,this,'S')")
            e.Row.Attributes.Add("OnMouseOut", "Resaltar(0,this,'S')")
            'e.Row.Attributes.Add("OnClick", "ResaltarfilaDetalle_net('',this,'DetalleAlumno.aspx?CodUniv=" & e.Row.Cells(1).Text & "&Nombres=" & e.Row.Cells(2).Text & "&cod_alu=" & fila.Row("codigo_alu") & "')")
            ' e.Row.Attributes.Add("OnClick", "javascript:__doPostBack('GridAlumnos','Select$" & e.Row.RowIndex & "');") 'location.href='DetalleAlumno.aspx?CodUniv=" & e.Row.Cells(1).Text & "&Nombres=" & e.Row.Cells(2).Text & "&cod_alu=" & fila.Row("codigo_alu") & "'")

            cod_alu = fila.Row("codigo_alu")
            nombres = fila.Row("alumno")
            If fila.Row("estadoDeuda_Alu") = 1 Then
                e.Row.Cells(5).Text = "Si"
                e.Row.Cells(5).ForeColor = Drawing.Color.Red
            Else
                e.Row.Cells(5).Text = "No"
                e.Row.Cells(5).ForeColor = Drawing.Color.Blue
            End If
            If fila.Row("estadoActual_Alu") = 1 Then
                e.Row.Cells(4).Text = "Activo"
                e.Row.Cells(4).ForeColor = Drawing.Color.Blue
            Else
                e.Row.Cells(4).Text = "Inactivo"
                e.Row.Cells(4).ForeColor = Drawing.Color.Red
            End If

            'Cambiado xDguevara 02.10.2012            
            e.Row.Cells(6).Text = "<a href='http://intranet.usat.edu.pe/rptusat/?/PRIVADOS/ACADEMICO/ACAD_RepAsistConsoliAlumnoMDL&mod=" & Request.QueryString("mod") & "&codigo_cac=" & Me.DdlCicloAcad.SelectedValue & "&codigo_alu=" & cod_alu & "' title='Clic aquí para mostrar el registro de asistencias'>Ver</a>"
            e.Row.Cells(7).Text = "<a href='http://intranet.usat.edu.pe/rptusat/?/PRIVADOS/ACADEMICO/ACAD_RepNotasConsoliAlumnoMDL&mod=" & Request.QueryString("mod") & "&codigo_cac=" & Me.DdlCicloAcad.SelectedValue & "&codigo_alu=" & cod_alu & "' title='Clic aquí para mostrar las notas parciales'>Ver</a>"

            If fnAdministradorSistema() Or fnEsDirectorAcademico() Or fnEsCoordinadorDA() Then
                e.Row.Cells(8).Visible = True

            Else
                e.Row.Cells(8).Visible = False
            End If


            'Response.Redirect("ReptConsolidadoWeb.aspx?codal=" & CInt(Me.GridAlumnos.DataKeys.Item(Me.GridAlumnos.SelectedIndex).Values(0)) & "&cac=" & Me.DdlCicloAcad.SelectedValue)
            'e.Row.Cells(6).Text = "<a href='ReptConsolidadoWebAsistenciasMDL.aspx?codal=" & cod_alu & "&cac=" & Me.DdlCicloAcad.SelectedValue & "' title='Clic aquí para mostrar el registro de asistencias'>Ver</a>"
        End If

    End Sub

    Protected Sub page_load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Try


            If (Session("id_per") Is Nothing) Then
                Response.Redirect("../../../../ErrorSistema.aspx")
            End If

            If Not IsPostBack Then
                Dim obj As New ClsConectarDatos
                obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
                obj.AbrirConexion()
                ClsFunciones.LlenarListas(Me.DdlCicloAcad, obj.TraerDataTable("ConsultarCicloAcademico", "TO", ""), "codigo_cac", "descripcion_cac")
                Me.DdlCicloAcad.SelectedIndex = 0
                obj.CerrarConexion()
                'Me.DdlBusqueda.SelectedValue = 2
                'test = Request.QueryString("mod")

                Me.hdFn.Value = Encriptar(fnVerificarFuncion().ToString)
                Me.TxtBusqueda.Focus()
            End If
        Catch ex As Exception
            Call mt_ShowMessage(ex.Message, MessageType.Error)
        End Try
    End Sub

    Protected Sub GridAlumnos_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridAlumnos.SelectedIndexChanged
        'Response.Redirect("ReptConsolidadoWeb.aspx?codal=" & CInt(Me.GridAlumnos.DataKeys.Item(Me.GridAlumnos.SelectedIndex).Values(0)) & "&cac=" & Me.DdlCicloAcad.SelectedValue)
    End Sub


#Region "Funciones"

    Private Function fnEsDirectorAcademico() As Boolean ' #EPENA 03/12/2019
        Try
            Dim rpta As Boolean = False
            Dim ctf As Integer = 0
            ctf = CInt(Desencriptar(Me.hdFn.Value.ToString))
            If ctf = 181 Then
                rpta = True
            Else
                rpta = False
            End If
            Return rpta
        Catch ex As Exception
            Return False
        End Try
    End Function

    Private Function fnEsCoordinadorDA() As Boolean ' #EPENA 03/12/2019

        Try

            Dim rpta As Boolean = False


            Dim ctf As Integer = 0

            ctf = CInt(Desencriptar(Me.hdFn.Value.ToString))


            If ctf = 85 Then
                rpta = True
            Else
                rpta = False
            End If

            Return rpta
        Catch ex As Exception
            Return False

        End Try

    End Function
    Private Function fnAdministradorSistema() As Boolean ' #EPENA 03/12/2019

        Try

            Dim rpta As Boolean = False


            Dim ctf As Integer = 0

            ctf = CInt(Desencriptar(Me.hdFn.Value.ToString))


            If ctf = 1 Then
                rpta = True
            Else
                rpta = False
            End If

            Return rpta
        Catch ex As Exception
            Return False

        End Try

    End Function

    Private Function fnVerificarFuncion() As Integer ' #EPENA 03/12/2019
        Dim dt As New Data.DataTable
        Dim cls As New ClsConectarDatos
        cls.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString

        Try

            Dim rpta As Boolean = False
            Dim tipo As String = ""

            '1	    ADMINISTRADOR DEL SISTEMA	
            '9	    DIRECTOR DE ESCUELA	
            '15 	DIRECTOR DE DEPARTAMENTO ACADEMICO
            '181	DIRECCIÓN ACADÉMICA 
            '182	COORDINADOR ACADÉMICO  
            '85	   COORD DIRECCION ACADÉMICA

            cls.AbrirConexion()
            dt = cls.TraerDataTable("MAT_consultarTipoFuncion", Session("id_per"), 1)
            cls.CerrarConexion()

            Dim ctf As Integer = 0

            If dt.Rows.Count > 0 Then

                For i As Integer = 0 To dt.Rows.Count - 1
                    If dt.Rows(i).Item("codigo_Tfu") = Request.QueryString("ctf") Then
                        ctf = dt.Rows(i).Item("codigo_Tfu")
                        'hdFn.Value = Encriptar(ctf.ToString)
                    End If
                Next

            End If

            Return ctf
        Catch ex As Exception

            Return 0
        End Try

    End Function
    Public Function fnDevuelveNumEntero(ByVal input As String) As Integer
        Dim r As Integer = 0

        If input = "" Then
            r = 0
        Else
            r = CInt(input)
        End If

        Return r
    End Function
    Public Function Encriptar(ByVal Input As String) As String  ' #EPENA 03/12/2019

        Dim IV() As Byte = ASCIIEncoding.ASCII.GetBytes("qualityi") 'La clave debe ser de 8 caracteres
        Dim EncryptionKey() As Byte = Convert.FromBase64String("rpaSPvIvVLlrcmtzPU9/c67Gkj7yL1S5") 'No se puede alterar la cantidad de caracteres pero si la clave
        Dim buffer() As Byte = Encoding.UTF8.GetBytes(Input)
        Dim des As TripleDESCryptoServiceProvider = New TripleDESCryptoServiceProvider
        des.Key = EncryptionKey
        des.IV = IV

        Return Convert.ToBase64String(des.CreateEncryptor().TransformFinalBlock(buffer, 0, buffer.Length()))

    End Function

    Public Function Desencriptar(ByVal Input As String) As String  ' #EPENA 03/12/2019
        Dim IV() As Byte = ASCIIEncoding.ASCII.GetBytes("qualityi") 'La clave debe ser de 8 caracteres
        Dim EncryptionKey() As Byte = Convert.FromBase64String("rpaSPvIvVLlrcmtzPU9/c67Gkj7yL1S5") 'No se puede alterar la cantidad de caracteres pero si la clave
        Dim buffer() As Byte = Convert.FromBase64String(Input)
        Dim des As TripleDESCryptoServiceProvider = New TripleDESCryptoServiceProvider
        des.Key = EncryptionKey
        des.IV = IV
        Return Encoding.UTF8.GetString(des.CreateDecryptor().TransformFinalBlock(buffer, 0, buffer.Length()))
    End Function
    Protected Sub mt_ShowMessage(ByVal Message As String, ByVal type As MessageType, Optional ByVal modal As Boolean = False)

        Page.RegisterStartupScript("Mensaje", "<script>ShowMessage('" & Message & "','" & type.ToString & "');</script>")

    End Sub
#End Region


End Class
