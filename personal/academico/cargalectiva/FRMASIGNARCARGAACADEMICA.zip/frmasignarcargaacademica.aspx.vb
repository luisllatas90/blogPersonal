﻿
Partial Class frmasignarcargaacademica
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If IsPostBack = False Then
            Dim codigo_tfu As Int16 = Request.QueryString("ctf")
            Dim codigo_usu As Integer = Request.QueryString("id")
            Dim Modulo As Integer = Request.QueryString("mod")
            Session("PermitirCarga") = "NO"
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            '=========================================
            'Llenas Ciclo & Escuela, Profesores
            '=========================================
            Dim objFun As New ClsFunciones
            objFun.CargarListas(Me.dpCodigo_cac, obj.TraerDataTable("ConsultarCicloAcademico", "UCI", 0), "codigo_cac", "descripcion_cac")
            objFun.CargarListas(Me.dpCodigo_cpf, obj.TraerDataTable("EVE_ConsultarCarreraProfesional", Modulo, codigo_tfu, codigo_usu), "codigo_cpf", "nombre_cpf", "--Seleccione la Carrera Profesional--")

            '=========================================
            'Obtener el Dpto. Académico como Director
            '=========================================
            Dim tblDpto As Data.DataTable
            tblDpto = obj.TraerDataTable("CAR_ConsultarProcesoCargaAcademica", 2, codigo_usu, codigo_tfu, 0, 0)
            If tblDpto.Rows.Count > 0 Then
                Me.lblnombre_dac.Text = Replace(tblDpto.Rows(0).Item("nombre_dac").ToString, "DEPARTAMENTO ACADEMICO", "DPTO:")
                Me.hdcodigo_dac.Value = tblDpto.Rows(0).Item("codigo_dac").ToString
                '=========================================
                'Cargar Profesores adscritos
                '=========================================
                objFun.CargarListas(Me.dpCodigo_per, obj.TraerDataTable("CAR_ConsultarProcesoCargaAcademica", 5, Me.hdcodigo_dac.Value, Me.hdCodigo_Cup.Value, Me.dpCodigo_cac.SelectedValue, 0), "codigo_per", "profesor", "--Seleccione el Profesor adscrito al Dpto.--")
            End If

            obj.CerrarConexion()
            obj = Nothing

            fnLoading(True)
            mostrar(1)
	    Me.lblmensaje.visible=false
            Me.ValidarPermisoAcciones()
        End If

    End Sub

    Private Sub fnLoading(ByVal sw As Boolean)
        If sw Then
            ' Response.Write(1 & "<br>")
            Me.loading.Attributes.Remove("class")
            Me.loading.Attributes.Add("class", "hidden")
        Else
            ' Response.Write(0 & "<br>")
            Me.loading.Attributes.Remove("class")
            Me.loading.Attributes.Add("class", "")
            ' Me.loading.Attributes.Add("class", "show")
        End If
    End Sub

    Protected Sub dpCodigo_cac_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dpCodigo_cac.SelectedIndexChanged
        Me.hdCodigo_Cup.Value = 0
	Me.grwGruposProgramados.visible=false
    End Sub
    Protected Sub grwGruposProgramados_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grwGruposProgramados.RowDataBound

        If e.Row.RowType = DataControlRowType.DataRow Then
            Dim fila As Data.DataRowView
            fila = e.Row.DataItem

            e.Row.Attributes.Add("OnMouseOver", "Resaltar(1,this,'S')")
            e.Row.Attributes.Add("OnMouseOut", "Resaltar(0,this,'S')")
            e.Row.Cells(0).Text = e.Row.RowIndex + 1
            e.Row.Cells(11).Text = IIf(fila.Row("estado_cup") = False, "Cerrado", "Abierto")
            e.Row.Attributes("OnClick") = Page.ClientScript.GetPostBackClientHyperlink(Me.grwGruposProgramados, "Select$" + e.Row.RowIndex.ToString)

           
            'Cargar Profesores y Horario
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            Dim gr As BulletedList = CType(e.Row.FindControl("lstProfesores"), BulletedList)
            gr.DataSource = obj.TraerDataTable("CAR_ConsultarProcesoCargaAcademica", 4, fila.row("codigo_cup"), Me.dpcodigo_cac.selectedvalue, 0, 0)
            gr.DataBind()
            obj.CerrarConexion()
            obj = Nothing
        End If
    End Sub
    Protected Sub grwGruposProgramados_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grwGruposProgramados.SelectedIndexChanged, cmdPopUp.Click
        Dim dt As Data.DataTable

        If Session("PermitirCarga") = "SI" Then

            mostrar(2)
            ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "DivLoad", "fnDivLoad('report',1000);", True)
            Me.hdCodigo_Cup.Value = Me.grwGruposProgramados.DataKeys.Item(Me.grwGruposProgramados.SelectedIndex).Values("codigo_cup").ToString
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            'Cargar Profesores asignados
            Me.dlProfesores.DataSource = obj.TraerDataTable("CAR_ConsultarProcesoCargaAcademica", 4, Me.hdCodigo_Cup.Value, 0, 0, 0)
            Me.dlProfesores.DataBind()

            'Cargar profesores sugeridos
            ClsFunciones.LlenarListas(Me.blstProfesoresSugeridos, obj.TraerDataTable("CAR_ConsultarProcesoCargaAcademica", 6, Me.hdcodigo_dac.Value, Me.hdCodigo_Cup.Value, Me.dpCodigo_cac.SelectedValue, 0), "codigo_per", "profesor")
            'Cargar Horario del curso

            'Response.Write(Me.grwGruposProgramados.Rows.Item(Me.grwGruposProgramados.SelectedIndex).Cells(15).Text)
            'ClsFunciones.LlenarListas(Me.bllHorarioCurso, obj.TraerDataTable("ConsultarHorarios", 4, Me.grwGruposProgramados.Rows.Item(Me.grwGruposProgramados.SelectedIndex).Cells(15).Text, 0, 0), "horas", "horas")
            'ClsFunciones.LlenarListas(Me.bllHorarioCurso, obj.TraerDataTable("ConsultarHorarios", 4, Me.hdCodigo_Cup.Value, 0, 0), "horas", "horas")
            dt = obj.TraerDataTable("ACAD_RetornaDocentesPermitidos", Me.hdCodigo_Cup.Value)
            Me.lblCarga.Text = (dt.Rows(0).Item("docentes")) & " de " & dt.Rows(0).Item("nrodocente_cup")

            obj.CerrarConexion()
            obj = Nothing

            fnListarHorario()
            Me.lblcurso.Text = CType(Me.grwGruposProgramados.Rows.Item(Me.grwGruposProgramados.SelectedIndex).Cells(1).FindControl("lblnombre_cur"), Label).Text
            Me.lblgrupo.Text = Me.grwGruposProgramados.Rows.Item(Me.grwGruposProgramados.SelectedIndex).Cells(2).Text

            Me.lblGrupoProfesores.Text = "PROFESORES ASIGNADOS (" & Me.dlProfesores.Items.Count & ")"

            Me.mpeFicha.Show()


        
        End If

    End Sub
    Protected Sub cmdGuardar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGuardar.Click
        Try

        
            Dim obj As New ClsConectarDatos
            Dim dt As New Data.DataTable
            Dim msj(1) As Object
            Dim strMax As String = ""
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString

            obj.AbrirConexion()

            dt = obj.TraerDataTable("ACAD_RetornaDocentesPermitidos", Me.hdCodigo_Cup.Value)

            If (dt.Rows.Count > 0) Then
                If (dt.Rows(0).Item("nrodocente_cup") >= dt.Rows(0).Item("docentes") + 1) Then
                    obj.Ejecutar("CAR_AgregarCargaAcademica", Me.dpCodigo_per.SelectedValue, Me.hdCodigo_Cup.Value, Request.QueryString("id"), Request.QueryString("mod"), "").copyto(msj, 0)






                    'Limpiar valores
                    Me.dlProfesores.DataSource = obj.TraerDataTable("CAR_ConsultarProcesoCargaAcademica", 4, Me.hdCodigo_Cup.Value, 0, 0, 0)
                    Me.dlProfesores.DataBind()

                    strMax = ""
                Else

                    strMax = " <b style='color:Red'>Ha superado el maximo de asignaci&oacute;n de docentes para el curso seleccionado</b>"

                End If


                dt = obj.TraerDataTable("ACAD_RetornaDocentesPermitidos", Me.hdCodigo_Cup.Value)
                Me.lblCarga.Text = (dt.Rows(0).Item("docentes")) & " de " & dt.Rows(0).Item("nrodocente_cup")
                Me.lblCargaReg.Text = strMax
                Me.lblCargaReg.Visible = True
            End If


            obj.CerrarConexion()
            obj = Nothing
            Me.lblGrupoProfesores.Text = "PROFESORES ASIGNADOS (" & Me.dlProfesores.Items.Count & ")"
            Me.mpeFicha.Show()
        Catch ex As Exception
            Response.Write(ex.Message)
        End Try

    End Sub
    Protected Sub cmdBuscar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdBuscar.Click
        ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "DivLoad", "fnDivLoad('report',1000);", True)
        Me.grwGruposProgramados.Visible = False
        Me.hdCodigo_Cup.Value = 0
        If Me.dpCodigo_cpf.SelectedValue <> -1 Then
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            Me.grwGruposProgramados.DataSource = obj.TraerDataTable("CAR_ConsultarProcesoProgramacionAcademica", 6, Me.dpCodigo_cac.SelectedValue, Me.dpCodigo_cpf.SelectedValue, Me.hdcodigo_dac.Value, Me.dpEstado.SelectedValue)
            Me.grwGruposProgramados.DataBind()
            Me.grwGruposProgramados.Visible = True
            obj.CerrarConexion()
            obj = Nothing
            Me.ValidarPermisoAcciones()
            Me.dpCodigo_per.SelectedValue = -1
        End If
    End Sub
    Protected Sub dlProfesores_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataListCommandEventArgs) Handles dlProfesores.DeleteCommand
        If Me.dlProfesores.DataKeys.Count >= 1 Then
            Dim dt As Data.DataTable
            Dim obj As New ClsConectarDatos
            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()
            obj.Ejecutar("EliminarCargaAcademica", CType(e.Item.FindControl("hdCodigo_per"), HiddenField).Value, Me.hdCodigo_Cup.Value, Request.QueryString("id"))
            'Cargar Profesores asignados
            Me.dlProfesores.DataSource = obj.TraerDataTable("CAR_ConsultarProcesoCargaAcademica", 4, Me.hdCodigo_Cup.Value, 0, 0, 0)
            Me.dlProfesores.DataBind()

            dt = obj.TraerDataTable("ACAD_RetornaDocentesPermitidos", Me.hdCodigo_Cup.Value)
            'Me.hdCodigo_Cup.Value = 0
            obj.CerrarConexion()
            obj = Nothing
            Me.mpeFicha.Show()
            Me.lblCarga.Text = (dt.Rows(0).Item("docentes")) & " de " & dt.Rows(0).Item("nrodocente_cup")
            Me.lblCargaReg.Visible = False
    
            'Dim sender As Object
            'cmdBuscar_Click(sender, New EventArgs())
        End If
    End Sub
    Protected Sub cmdEnviar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEnviar.Click
        Dim obj As New ClsConectarDatos
        obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
        Try
            obj.AbrirConexion()
            obj.Ejecutar("AgregarAccesoRecurso", "A", Request.QueryString("id"), Request.QueryString("id"), "cargaacademica", 0, True, True, True, True, CDate(Now), CDate(DateAdd(DateInterval.Day, 1, Now)), Me.txtmotivo.Text.Trim)
            obj.CerrarConexion()
            obj = Nothing
            Me.EnviarMensaje()
            Page.RegisterStartupScript("Solicitar", "<script>alert('Se ha enviado correctamente su solicitud de acceso. \nPor favor espere mientras ViceRectorado Académico responda su Solicitud vía E-mail')</script>")
        Catch ex As Exception
            obj = Nothing
            Page.RegisterStartupScript("Solicitar", "<script>alert('Ocurrió un Error al Enviar la solicitud')</script>")
        End Try
    End Sub
    Public Sub EnviarMensaje()
        'Enviar email
        Dim ObjMailNet As New ClsMail
        Dim Mensaje, Correo, AsuntoCorreo, ConCopiaA As String

        Mensaje = "<h3 style='font-color:blue'>Hay 1 Solicitud Pendiente para Habilitar el acceso a Modificar Carga Académica, registrada el " & Now.ToString & "</h3>"
        Mensaje = Mensaje & "<h4>La Solicitud ha sido requerda por la Dirección del " & Me.lblnombre_dac.Text & "</h2>"
        '---------------------------------------------------------------------------------------------------------------
        'Fecha: 29.10.2012
        'Usuario: dguevara
        'Modificacion: Se modifico el http://www.usat.edu.pe por http://intranet.usat.edu.pe
        '----------------------
        Mensaje = Mensaje & "<h4>Para atender esta solicitud, <a href=""http://intranet.usat.edu.pe/campusvirtual/personal/academico/cargalectiva/frmsolicitudcambios.aspx?id=296"">Haga clic aquí</a></h4>"
        Mensaje = Mensaje & "<h5>Se recomienda no reeenviar este email, ya que contiene datos de acceso al sistema. <br>Si el enlace no funciona ingresar a www.usat.edu.pe/campusvirtual, Módulo Académico, Movimientos, Carga Académica, Habilitar acceso</h5>"

        Correo = "mcervera@usat.edu.pe"
        AsuntoCorreo = "1 Solicitud Pendiente para habilitar Acceso a Modificar Carga Académica"
        ObjMailNet.EnviarMail("campusvirtual@usat.edu.pe", "Módulo de Carga Académica", Correo, AsuntoCorreo, Mensaje, True)
        ObjMailNet = Nothing
    End Sub
    Private Sub ValidarPermisoAcciones()
	if Me.dpCodigo_cpf.SelectedValue <> -1 And me.grwGruposProgramados.rows.count>0 then

        Dim codigo_tfu As Int16 = Request.QueryString("ctf")
        Dim codigo_usu As Integer = Request.QueryString("id")
        '=========================================
        'Verificar permisos de acción
        '=========================================
            Dim Agregar, Modificar, Eliminar As Boolean
            
        If codigo_tfu <> 1 Then
                Dim tblPermisos As Data.DataTable
                Dim obj As New ClsConectarDatos
                obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
                obj.AbrirConexion()
                tblPermisos = obj.TraerDataTable("ValidarPermisoAccionesEnProcesoMatriculaCarga", "0", Me.dpCodigo_cac.SelectedValue, codigo_usu, "cargaacademica")
                If tblPermisos.Rows.Count > 0 Then
                    Agregar = tblPermisos.Rows(0).Item("agregar_acr")
                    Modificar = tblPermisos.Rows(0).Item("modificar_acr")
                    Eliminar = tblPermisos.Rows(0).Item("eliminar_acr")

                Else

                End If
                ' FIN
                obj.CerrarConexion()
                obj = Nothing
        Else
            Agregar = True
            Modificar = True
                Eliminar = True


        End If

        '=========================================
        'Validar Acción de Botones
        '=========================================
            Me.lblMensaje.visible = True

        If Agregar = True Then
                Me.cmdAgregar.Visible = False ' True

            Me.lnkSolicitar.Visible = False

                Me.lblMensaje.Text = "<img src='../../../images/bien.gif' style='width:15px;height:15px;'>&nbsp;Su acceso para realizar modificaciones ha sido Habilitado"
                Session("PermitirCarga") = "SI"
        Else
            Me.lnkSolicitar.Visible = True
                Me.lblMensaje.Text = "<img src='../../../images/bloquear.gif' style='width:15px;height:15px;'>&nbsp;El Acceso para Agregar/Modificar la Carga Académica ha finalizado."
                Me.cmdAgregar.Visible = False
                Session("PermitirCarga") = "NO"
        End If
	End if
    End Sub


 
    Protected Sub blstProfesoresSugeridos_Click(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.BulletedListEventArgs) Handles blstProfesoresSugeridos.Click
        dpCodigo_per.SelectedValue = blstProfesoresSugeridos.Items(e.Index).Value
        VerificaCruce()

    End Sub

    Protected Sub cmdAgregar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAgregar.Click
        'Set rs=ObjCarga.Consultar("ACAD_RetornaDocentesPermitidos","FO",codigo_cup)	
    End Sub

    Protected Sub dpCodigo_per_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dpCodigo_per.SelectedIndexChanged

        VerificaCruce()
        ConsultarDisponibilidadHorarioDocente()

    End Sub
    Private Sub VerificaCruce()
        Dim obj As New ClsConectarDatos
        Dim dt As New Data.DataTable

        obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
        obj.AbrirConexion()

        dt = obj.TraerDataTable("ACAD_ConsultarCurceAsignacionCarga", Me.dpCodigo_cac.selectedvalue, Me.dpCodigo_per.SelectedValue, Me.hdCodigo_Cup.Value)
        If dt.Rows.Count > 0 Then
            Me.lblMensajeCruce.Text = "El horario del profesor presenta: " & dt.Rows.Count & " cruce(s) de horario."

            Me.dgvCruceHorarioDocente.DataSource = dt
            Me.dgvCruceHorarioDocente.DataBind()

        Else
            Me.lblMensajeCruce.Text = ""
            Me.dgvCruceHorarioDocente.DataBind()
        End If
        obj.CerrarConexion()
        obj = Nothing
        Me.mpeFicha.Show()
    End Sub

    Protected Sub dlProfesores_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles dlProfesores.SelectedIndexChanged

    End Sub

    Protected Sub cmdCancelar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancelar.Click
        'Dim sender As Object
        cmdBuscar_Click(sender, New EventArgs())
        mostrar(1)
        ScriptManager.RegisterStartupScript(Me, Me.[GetType](), "DivLoad", "fnDivLoad('report',1000);", True)
    End Sub

    Protected Sub grwGruposProgramados_PreRender(ByVal sender As Object, ByVal e As System.EventArgs) Handles grwGruposProgramados.PreRender
        If grwGruposProgramados.Rows.Count > 0 Then
            grwGruposProgramados.UseAccessibleHeader = True
            grwGruposProgramados.HeaderRow.TableSection = TableRowSection.TableHeader
        End If

    End Sub

    Private Sub mostrar(ByVal tipo As Int16)
        If tipo = 1 Then
            PanelLista.Visible = True
            PanelRegistro.Visible = False
        ElseIf tipo = 2 Then
            PanelLista.Visible = False
            PanelRegistro.Visible = True
        End If

    End Sub

    Private Sub fnListarHorario()
        Dim obj As New ClsConectarDatos
        Dim dt As New Data.DataTable

        obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
        obj.AbrirConexion()

        dt = obj.TraerDataTable("ConsultarHorarios", 22, Me.hdCodigo_Cup.Value, 0, 0)
        If dt.Rows.Count > 0 Then
            Me.gDataHorarioCurso.DataSource = dt
            Me.gDataHorarioCurso.DataBind()
        End If
        obj.CerrarConexion()
        obj = Nothing
    End Sub
    Private Sub ConsultarDisponibilidadHorarioDocente()
        Try

            Dim obj As New ClsConectarDatos
            Dim tb As New Data.DataTable

            obj.CadenaConexion = ConfigurationManager.ConnectionStrings("CNXBDUSAT").ConnectionString
            obj.AbrirConexion()

            tb = obj.TraerDataTable("ACAD_RestriccionPersonal_Consultar", "4", 0, 0, Me.dpCodigo_cac.SelectedValue, Me.dpCodigo_per.SelectedValue, 0, "")
            Me.gDataHorarioDisponible.DataSource = tb
            Me.gDataHorarioDisponible.DataBind()
            obj.CerrarConexion()
            obj = Nothing
        Catch ex As Exception
            Dim script As String = "fnMensaje('error','" & ex.Message & "'); "
            ScriptManager.RegisterStartupScript(Me, GetType(Page), "alert", script, True)
        End Try
    End Sub
    Protected Sub gDataHorarioCurso_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles gDataHorarioCurso.RowDataBound
        Dim index As Integer = 0
        If e.Row.RowType = DataControlRowType.DataRow Then
            index = e.Row.RowIndex
            Dim checkAcceso As CheckBox
            checkAcceso = e.Row.FindControl("chkElegir")

        
            checkAcceso.Checked = True


        End If
    End Sub
End Class

